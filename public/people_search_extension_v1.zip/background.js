// F:\Imtiaj Sajin\extension\background.js
// ============================================
// BACKGROUND SERVICE WORKER - OPTIMIZED ASYNC VERSION
// Handles all scraping operations with parallel processing
// ============================================

let currentStatus = {
  isRunning: false,
  message: 'Ready to start',
  className: '',
  details: {
    total: 0,
    completed: 0,
    failed: 0,
    inProgress: 0
  }
};

// ===== PLATFORM-SPECIFIC EXTRACTORS =====
// ← CHANGE: Added separate extractor for SearchPeopleFree
function extractFpsPersonUrl(ldJsonArray) {
  if (!Array.isArray(ldJsonArray)) return null;

  for (const item of ldJsonArray) {
    if (item['@type'] === 'Person' && item.url) return item.url;
    if (item['@graph'] && Array.isArray(item['@graph'])) {
      for (const graphItem of item['@graph']) {
        if (graphItem['@type'] === 'Person' && graphItem.url) return graphItem.url;
      }
    }
  }
  return null;
}

// ← CHANGE: New function for SearchPeopleFree – parses HTML to find person link
function extractSpfPersonUrl(ldJson) {
  const data = typeof ldJson === "string" ? JSON.parse(ldJson) : ldJson;

  if (!Array.isArray(data)) return null;

  for (const block of data) {
    if (
      block["@type"] === "ItemList" &&
      Array.isArray(block.itemListElement) &&
      block.itemListElement.length > 0
    ) {
      return block.itemListElement[0].url || null;
    }
  }

  return null;
}


// ===== STATUS MANAGEMENT =====
function updateStatus(message, className = '', details = null) {
  currentStatus.isRunning = true;
  currentStatus.message = message;
  currentStatus.className = className;
  
  if (details) {
    currentStatus.details = { ...currentStatus.details, ...details };
  }
  
  // Broadcast to all popup instances
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
  
  console.log(`[STATUS] ${message}`, details || '');
}

function finishStatus(message, className = 'success') {
  currentStatus.isRunning = false;
  currentStatus.message = message;
  currentStatus.className = className;
  
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
  
  console.log(`[FINISHED] ${message}`);
}

// ===== MESSAGE LISTENER =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'START_SCRAPING') {
    const { workerId } = request;
    
    if (currentStatus.isRunning) {
      sendResponse({ 
        success: false, 
        message: 'A scraping task is already running' 
      });
      return true;
    }
    
    // Start the scraping process (non-blocking)
    startScrapingProcess(workerId);
    
    sendResponse({ 
      success: true, 
      message: 'Scraping started in background' 
    });
    
    return true;
  }
  
  if (request.type === 'GET_STATUS') {
    sendResponse({ status: currentStatus });
    return true;
  }
});

// ===== MAIN SCRAPING LOGIC (ASYNC & PARALLEL) =====
async function startScrapingProcess(workerId) {
  try {
    // Reset status details
    currentStatus.details = { total: 0, completed: 0, failed: 0, inProgress: 0 };
    
    updateStatus('Fetching tasks from API...');

    // === Step 1: Get tasks from API ===
    const tasks = await fetchTasksFromApi(5);

    if (tasks.length === 0) {
      finishStatus('No tasks available', 'error');
      return;
    }
    // ← CHANGE: Assign platforms – first 2 FPS, next 3 SPF
    const assignedTasks = [];
    tasks.forEach((task, index) => {
      if (index < 2 && task.fastpeoplesearch_url) {
        assignedTasks.push({ ...task, platform: 'fps', startUrl: task.fastpeoplesearch_url });
      } else if (task.searchpeoplefree_url) {
        assignedTasks.push({ ...task, platform: 'spf', startUrl: task.searchpeoplefree_url });
      }
    });

    if (assignedTasks.length === 0) {
      finishStatus('No valid URLs found', 'error');
      return;
    }

    updateStatus(`Received ${assignedTasks.length} tasks. Starting parallel processing...`, '', {
      total: assignedTasks.length,
      completed: 0,
      failed: 0,
      inProgress: assignedTasks.length
    });

    // === Step 2: Process ALL tasks in parallel ===
    const taskPromises = assignedTasks.map(task => 
      processSingleTask(task, workerId)
    );

    // Wait for all tasks to complete
    const results = await Promise.allSettled(taskPromises);

    // Count successes and failures
    let successCount = 0;
    let failCount = 0;

    results.forEach(result => {
      if (result.status === 'fulfilled' && result.value.success) {
        successCount++;
      } else {
        failCount++;
      }
    });

    const finalMessage = `✓ All tasks completed! Success: ${successCount}, Failed: ${failCount}`;
    finishStatus(finalMessage, successCount > 0 ? 'success' : 'error');

  } catch (error) {
    console.error('Fatal error:', error);
    finishStatus(`Error: ${error.message}`, 'error');
  }
}

// ===== PROCESS SINGLE TASK (INDEPENDENT & ASYNC) =====
async function processSingleTask(task, workerId) {
  const startTime = Date.now();
  console.log(`[TASK ${task.taskId}] Starting...`);

  try {
    // Step 1: Open tab with placeholder URL
    const tab = await chrome.tabs.create({
      url: task.startUrl,
      active: false
    });

    console.log(`[TASK ${task.taskId}] Tab ${tab.id} opened`);

    // Step 2: Wait for placeholder page to load and extract target URL
    const targetUrl = await waitAndExtractTargetUrl(tab.id, task.taskId, task.platform, task.raw_name);

    if (!targetUrl) {
      throw new Error('Failed to extract target URL from placeholder page');
    }

    console.log(`[TASK ${task.taskId}] Target URL extracted: ${targetUrl}`);

    // Step 3: Redirect to target URL
    await chrome.tabs.update(tab.id, { url: targetUrl });
    console.log(`[TASK ${task.taskId}] Redirected to target profile`);

    // Step 4: Wait for final page to load and extract data
    const finalData = await waitAndExtractFinalData(tab.id, task.taskId, task.platform, task.raw_name);
    if (!finalData.extractedData) {
      throw new Error('Failed to extract data from final page');
    }

    console.log(`[TASK ${task.taskId}] Data extracted successfully`);

    // Step 5: Send to API
    await sendToApi(task.taskId, finalData.extractedData, targetUrl, workerId,task.platform === 'fps' ? 1 : 2);

    // Step 6: Close the tab
    try {
      await chrome.tabs.remove(tab.id);
    } catch (e) {
      console.warn(`[TASK ${task.taskId}] Failed to close tab: ${e.message}`);
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`[TASK ${task.taskId}] ✓ Completed in ${duration}s`);

    // Update completed count
    currentStatus.details.completed++;
    currentStatus.details.inProgress--;
    updateStatus(
      `Processing: ${currentStatus.details.completed}/${currentStatus.details.total} completed, ${currentStatus.details.failed} failed`,
      '',
      currentStatus.details
    );

    return { success: true, taskId: task.taskId };

  } catch (error) {
    console.error(`[TASK ${task.taskId}] ✗ Failed:`, error.message);

    // Update failed count
    currentStatus.details.failed++;
    currentStatus.details.inProgress--;
    updateStatus(
      `Processing: ${currentStatus.details.completed}/${currentStatus.details.total} completed, ${currentStatus.details.failed} failed`,
      '',
      currentStatus.details
    );

    return { success: false, taskId: task.taskId, error: error.message };
  }
}

// ===== WAIT AND EXTRACT TARGET URL (PLATFORM-AWARE) =====
// ← CHANGE: Added platform and raw_name parameters
async function waitAndExtractTargetUrl(tabId, taskId, platform, raw_name, maxWait = 30000) {
  const startTime = Date.now();
  const checkInterval = 1000;

  while (Date.now() - startTime < maxWait) {
    try {
      const [injectionResult] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const isChallenge =
            document.title.includes('Just a moment') ||
            document.querySelector('iframe[src*="challenges.cloudflare"]') ||
            document.body.innerText.includes('Checking your browser');

          if (isChallenge) return null;

          return document.documentElement.outerHTML;
        }
      });

      const pageHtml = injectionResult?.result;

      if (pageHtml) {
        let personUrl = null;
        const ldJson = extractLdJsonFromHtml(pageHtml);         // Create a Blob from the JSON object
        // const blob = new Blob([JSON.stringify(ldJson)], { type: 'application/json' });
        
        // // Create a download link and trigger the download
        // const link = document.createElement('a');
        // link.href = URL.createObjectURL(blob);
        // link.download = 'ldjson.json';
        // link.click(); 
        if (platform === 'fps') {
          personUrl = extractFpsPersonUrl(ldJson);
        } else if (platform === 'spf') {
          personUrl = extractSpfPersonUrl(ldJson);
          console.log("Extracted SPF URL:", personUrl);
        }

        if (personUrl) {
          const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
          console.log(`[TASK ${taskId}] Target URL found in ${elapsed}s`);
          return personUrl;
        }
      }
    } catch (error) {
      console.log(`[TASK ${taskId}] Waiting...`);
    }

    await sleep(checkInterval);
  }

  throw new Error(`Timeout extracting target URL`);
}

// ===== WAIT AND EXTRACT FINAL DATA (OPTIONAL PLATFORM TWEAK) =====
// ← CHANGE: Added platform parameter (currently same logic for both)
// ===== WAIT AND EXTRACT FINAL DATA (FIXED) =====
// ===== WAIT AND EXTRACT FINAL DATA (NO TIMEOUT FAILURES) =====
async function waitAndExtractFinalData(tabId, taskId, platform, raw_name, maxWait = 90000) {
  const startTime = Date.now();
  const checkInterval = 2000;
  const minWait = 10000;

  await sleep(minWait);

  let bestExtractedData = null;  // Store the best we have so far

  while (Date.now() - startTime < maxWait) {
    try {
      const [injectionResult] = await chrome.scripting.executeScript({
        target: { tabId },
        func: (plat) => {
          const isChallenge =
            document.title.includes('Just a moment') ||
            document.querySelector('iframe[src*="challenges.cloudflare"]') ||
            document.body.innerText.includes('Checking your browser');

          if (isChallenge) return null;

          const hasLdJson = document.querySelectorAll('script[type="application/ld+json"]').length > 0;
          const hasWamInit = plat === 'fps' ? document.documentElement.outerHTML.includes('wam.init') : true;

          if (hasLdJson && hasWamInit) {
            return document.documentElement.outerHTML;
          }
          return null;
        },
        args: [platform]
      });

      const pageHtml = injectionResult?.result;

      if (pageHtml) {
        const ldJson = extractLdJsonFromHtml(pageHtml);

        let extractedData = {
          name: 'Unknown from first',
          phone_numbers: [],
          best_phone_number: '',
          emails: [],
          best_email: ''
        };

        if (platform === 'fps') {
          const awmJson = extractWamInitObject(pageHtml, true);
          const personLdJson = ldJson.find(item => item['@type'] === 'Person') || {};

          const nameFromAwm = awmJson 
            ? `${awmJson.fn || ''} ${awmJson.mn || ''} ${awmJson.ln || ''}`.trim().replace(/\s+/g, ' ')
            : personLdJson.name || 'Unknown from awm';

          extractedData.name = nameFromAwm;
          extractedData.best_phone_number = awmJson?.phone || '';
          extractedData.best_email = awmJson?.email || '';
          extractedData.phone_numbers = extractPhoneNumbers(ldJson);

          const faqMainEntities = extractFAQPage(ldJson);
          const emailsFromFaq = emailExtractorRegx(faqMainEntities);
          if (emailsFromFaq) {
            extractedData.emails = emailsFromFaq.split(',').filter(e => e);
          }
        } 
        else if (platform === 'spf') {
          const faqMainEntities1 = extractFAQPage(ldJson);
          const emailsFromFaq = emailExtractorRegx(faqMainEntities1);
          const name = spfExtractName(ldJson);
          const phoneNumbers = spfExtractPhoneNumbers(ldJson);
          const emails = spfExtractEmails(ldJson);

          if (emailsFromFaq) {
            extractedData.best_email = emailsFromFaq;
          }


          extractedData.name = name || 'Unknown 2';
          extractedData.phone_numbers = phoneNumbers;
          extractedData.best_phone_number = '';
          extractedData.emails = emails;
        }

        // Update best data if we have more than before
        if (
          extractedData.phone_numbers.length > (bestExtractedData?.phone_numbers.length || 0) ||
          extractedData.emails.length > (bestExtractedData?.emails.length || 0) ||
          extractedData.best_phone_number || extractedData.best_email
        ) {
          bestExtractedData = extractedData;
        }

        // If we have ANY contact info → return immediately
        if (
          extractedData.phone_numbers.length > 0 ||
          extractedData.emails.length > 0 ||
          extractedData.best_phone_number ||
          extractedData.best_email
        ) {
          const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
          console.log(`[TASK ${taskId}] Final data extracted (${platform.toUpperCase()}) in ${elapsed}s - HAS contacts`);
          return { ldJson, awmJson: platform === 'fps' ? extractWamInitObject(pageHtml, true) : null, extractedData };
        }
      }
    } catch (error) {
      console.log(`[TASK ${taskId}] Waiting for better data...`);
    }

    await sleep(checkInterval);
  }

  // === AFTER 90 SECONDS: Return whatever we have (even if empty) ===
  const finalExtractedData = bestExtractedData || {
    name: 'Unknown',
    phone_numbers: [],
    best_phone_number: '',
    emails: [],
    best_email: ''
  };

  const totalElapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log(`[TASK ${taskId}] Max wait reached (${totalElapsed}s) - NO contacts found, returning empty`);

  return { 
    ldJson: [], 
    awmJson: null, 
    extractedData: finalExtractedData 
  };
}

// ===== SEND TO API (PLATFORM-AWARE) =====
// ← CHANGE: Added platformId parameter
async function sendToApi(taskId, extractedData, targetUrl, workerId, platformId) {
  console.log(`[TASK ${taskId}] Sending API request...`);

  const apiPayload = {
    scraped_name: extractedData.name,
    scraped_emails: Array.isArray(extractedData.emails)
      ? extractedData.emails.join(',')
      : (extractedData.emails ?? ""),
    scraped_numbers: Array.isArray(extractedData.phone_numbers)
      ? extractedData.phone_numbers.join(',')
      : (extractedData.phone_numbers ?? ""),
    best_email: extractedData.best_email,
    best_number: extractedData.best_phone_number,
    status: "done",
    scrapped_from: platformId,
    scraped_by: workerId,
    profile_url: targetUrl,
  };

  console.log(`[TASK ${taskId}] API Payload:`, apiPayload);

  const response = await fetch(`https://backendproperty.bulkscraper.cloud/api/data/${taskId}/update`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(apiPayload)
  });

  console.log(`[TASK ${taskId}] API Response status: ${response.status} ${response.statusText}`);

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`[TASK ${taskId}] API Error body:`, errorText);
    throw new Error(`API call failed: ${response.status} ${response.statusText} - ${errorText}`);
  }

  console.log(`[TASK ${taskId}] API update successful`);
}

// ===== HELPER FUNCTIONS =====

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ← CHANGE: Now fetches all URL fields
async function fetchTasksFromApi(limit = 10) {
  const response = await fetch(
    `https://backendproperty.bulkscraper.cloud/api/data/top/${limit}`,
    { method: "GET", redirect: "follow" }
  );

  if (!response.ok) throw new Error("Failed to fetch tasks from API");

  const data = await response.json();

  return data.map((item, index) => ({
    taskId: item.id ?? `task_${index}`,
    fastpeoplesearch_url: item.fastpeoplesearch_url,
    searchpeoplefree_url: item.searchpeoplefree_url,
    raw_name: item.raw_name,
  }));
}

function extractLdJsonFromHtml(htmlInput) {
  const regex = /<script\s+type=["']application\/ld\+json["']>(.*?)<\/script>/gis;
  const results = [];
  let match;

  while ((match = regex.exec(htmlInput)) !== null) {
    let rawContent = match[1].trim();

    if (rawContent) {
      try {
        rawContent = rawContent.replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "");
        rawContent = rawContent.replace(/;\s*$/, "");
        rawContent = rawContent.replace(/,(\s*[}\]])/g, "$1");

        const jsonObject = JSON.parse(rawContent);

        if (Array.isArray(jsonObject)) {
          results.push(...jsonObject);
        } else {
          results.push(jsonObject);
        }

      } catch (e) {
        console.error("Failed to parse JSON:", e.message);
      }
    }
  }
  return results;
}

function extractPersonUrl(ldJsonArray) {
  if (!Array.isArray(ldJsonArray)) return null;

  for (const item of ldJsonArray) {
    if (item['@type'] === 'Person' && item.url) {
      return item.url;
    }

    if (item['@graph'] && Array.isArray(item['@graph'])) {
      for (const graphItem of item['@graph']) {
        if (graphItem['@type'] === 'Person' && graphItem.url) {
          return graphItem.url;
        }
      }
    }
  }

  return null;
}

function extractPhoneNumbers(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  for (const item of ldJson) {
    if (item['@type'] === 'Person' && item.telephone) {
      return Array.isArray(item.telephone) ? item.telephone : [item.telephone];
    }

    if (item['@graph'] && Array.isArray(item['@graph'])) {
      for (const graphItem of item['@graph']) {
        if (graphItem['@type'] === 'Person' && graphItem.telephone) {
          return Array.isArray(graphItem.telephone) ? graphItem.telephone : [graphItem.telephone];
        }
      }
    }
  }

  return [];
}

function extractWamInitObject(htmlContent, decodeEntities = false) {
  const match = htmlContent.match(/wam\.init\({([^}]+(?:}[^}]*)*)\}\);/s);
  if (!match) return null;

  const content = match[1];
  const result = {};

  const regex = /(\w+)\s*:\s*'([^']*)'|(\w+)\s*:\s*"([^"]*)"|(\w+)\s*:\s*(\w+(?:\s*==\s*'[^']*'\s*\?\s*\w+\s*:\s*\w+)?)/g;

  let m;
  while ((m = regex.exec(content)) !== null) {
    if (m[1]) {
      result[m[1]] = m[2];
    } else if (m[3]) {
      result[m[3]] = m[4];
    } else if (m[5]) {
      const value = m[6];
      if (value === 'true') result[m[5]] = true;
      else if (value === 'false') result[m[5]] = false;
      else if (value.includes('?')) result[m[5]] = false;
      else result[m[5]] = value;
    }
  }

  return standardizeData(result, decodeEntities);
}

function standardizeData(obj, decodeEntities) {
  if (!obj || typeof obj !== 'object') return obj;

  if (Array.isArray(obj)) {
    return obj.map(item => standardizeData(item, decodeEntities));
  }

  const result = {};

  for (const key in obj) {
    let value = obj[key];

    if (typeof value === 'string') {
      value = decodeURIComponent(value.replace(/\+/g, ' '));

      if (decodeEntities) {
        value = decodeHTMLEntities(value);
      }

      if (isEmail(value)) {
        value = value.toLowerCase().trim();
      }

      if (isPhone(value)) {
        value = standardizePhone(value);
      }
    } else if (typeof value === 'object' && value !== null) {
      value = standardizeData(value, decodeEntities);
    }

    result[key] = value;
  }

  return result;
}

function isEmail(str) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
}

function isPhone(str) {
  const cleaned = str.replace(/[\s\-\(\)\+\.]/g, '');
  return /^\d{7,15}$/.test(cleaned);
}

function standardizePhone(phone) {
  let cleaned = phone.trim();
  const hasPlus = cleaned.startsWith('+');
  cleaned = cleaned.replace(/\D/g, '');

  return hasPlus ? '+' + cleaned : cleaned;
}

function decodeHTMLEntities(str) {
  const entities = {
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&#39;': "'",
    '&apos;': "'",
    '&#x27;': "'",
    '&#x2F;': '/',
    '&nbsp;': ' '
  };

  return str.replace(/&[^;]+;/g, match => entities[match] || match);
}

console.log('Background service worker initialized - OPTIMIZED ASYNC VERSION');




// Helper function to extract FAQ main entities from LD+JSON data
function extractFAQPage(ldJsonArray) {
  console.log("Extracting FAQPage from LD+JSON:", ldJsonArray);
  
  if (!Array.isArray(ldJsonArray)) return null;
  
  for (const item of ldJsonArray) {
    // Check if this is a FAQPage type
    if (item['@type'] === 'FAQPage' && item.mainEntity) {
      return item.mainEntity; // Return the array of questions
    }
  }
  
  return null;
}


// Function to extract emails using regex from FAQ main entities
function emailExtractorRegx(mainEntity) {
    // If no mainEntity found or it's not an array, return empty string
    if (!mainEntity || !Array.isArray(mainEntity)) return "";

    const emailRegex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g;
    const emailSet = new Set();

    // Loop through each FAQ entity (Question/Answer pair)
    for (const item of mainEntity) {
        // Only target the 'text' field inside 'acceptedAnswer' as requested
        const textContent = item?.acceptedAnswer?.text;
        
        if (textContent && typeof textContent === "string") {
            const matches = textContent.match(emailRegex);
            if (matches) {
                matches.forEach(email => {
                    // Clean up and add to set to avoid duplicates
                    emailSet.add(email.toLowerCase().trim());
                });
            }
        }
    }

    // Return as a comma-separated string for your API
    return Array.from(emailSet).join(",");
}

// ===== SPF-SPECIFIC EXTRACTORS =====

function spfExtractName(ldJson) {
  if (!Array.isArray(ldJson)) return '';

  // Look for the Person block
  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (personBlock && personBlock.name) {
    return personBlock.name.trim();
  }

  return '';
}

function spfExtractPhoneNumbers(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (!personBlock || !personBlock.telephone) return [];

  // telephone can be string or array
  if (typeof personBlock.telephone === 'string') {
    return [personBlock.telephone.trim()];
  }

  if (Array.isArray(personBlock.telephone)) {
    return personBlock.telephone.map(num => num.trim()).filter(num => num);
  }

  return [];
}

function spfExtractEmails(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (!personBlock || !personBlock.email) return [];

  // email can be string or array
  if (typeof personBlock.email === 'string') {
    return [personBlock.email.trim().toLowerCase()];
  }

  if (Array.isArray(personBlock.email)) {
    return personBlock.email.map(email => email.trim().toLowerCase()).filter(email => email);
  }

  return [];
}

// ===== SPF-SPECIFIC: Extract FAQ mainEntity =====
function spfExtractFAQ(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  // Find the FAQPage block
  const faqBlock = ldJson.find(block => block['@type'] === 'FAQPage');

  if (faqBlock && Array.isArray(faqBlock.mainEntity)) {
    return faqBlock.mainEntity;
  }

  return [];
}