// F:\Imtiaj Sajin\extension\background.js
// ============================================
// BACKGROUND SERVICE WORKER - OPTIMIZED ASYNC VERSION
// Handles all scraping operations with parallel processing
// ============================================
chrome.alarms.create('keepAlive', { periodInMinutes: 0.1 });

let currentStatus = {
  isRunning: false,
  message: 'Ready to start',
  className: '',
  tasks: [], // <--- ADD THIS: To store the 5 individual task loaders
  details: {
    total: 0,
    completed: 0,
    failed: 0,
    inProgress: 0
  }
};

// ===== PLATFORM-SPECIFIC EXTRACTORS =====
// ← CHANGE: Added separate extractor for SearchPeopleFree
// function extractFpsPersonUrl(ldJsonArray) {
//   if (!Array.isArray(ldJsonArray)) return null;

//   for (const item of ldJsonArray) {
//     if (item['@type'] === 'Person' && item.url) return item.url;
//     if (item['@graph'] && Array.isArray(item['@graph'])) {
//       for (const graphItem of item['@graph']) {
//         if (graphItem['@type'] === 'Person' && graphItem.url) return graphItem.url;
//       }
//     }
//   }
//   return null;
// }

function extractFpsPersonUrl(ldJsonArray, targetName) {
  if (!Array.isArray(ldJsonArray) || !targetName || typeof targetName !== "string") {
    return { url: null, score: 0 };
  }

  // 1. Normalization Utility
  const normalize = (str) => {
    if (!str) return "";
    return str.toLowerCase()
      .replace(/[^a-z0-9 ]/g, " ") // Remove punctuation but keep spaces
      .trim()
      .replace(/\s+/g, " ");       // Collapse multiple spaces
  };

  const normalizedTarget = normalize(targetName);
  const targetWords = normalizedTarget.split(" ").filter(Boolean);

  if (targetWords.length === 0) return { url: null, score: 0 };

  let bestUrl = null;
  let bestScore = 0;

  // 2. Iterate through the LD+JSON blocks
  for (const item of ldJsonArray) {
    // FPS structure: Some items are direct Persons, some are Organizations, etc.
    if (item["@type"] === "Person") {
      const result = evaluateFpsPerson(item, normalizedTarget, targetWords, normalize);
      
      if (result.score > bestScore) {
        bestScore = result.score;
        bestUrl = result.url;
      }
    }
  }
  // 3. Early Return/Confidence Thresholds
  return { url: bestUrl, score: Math.round(bestScore) };
}

/**
 * Evaluates a single Person object from FPS LD+JSON
 */
function evaluateFpsPerson(person, normalizedTarget, targetWords, normalize) {
  const mainName = normalize(person.name || "");
  
  // additionalName in FPS is often an array of aliases
  const aliases = Array.isArray(person.additionalName) 
    ? person.additionalName.map(normalize) 
    : (person.additionalName ? [normalize(person.additionalName)] : []);

  // Collect all name variants to check
  const candidates = [
    { text: mainName, priority: 1.0 },
    ...aliases.map(a => ({ text: a, priority: 0.9 })) // Aliases are slightly less prioritized than the primary display name
  ].filter(c => c.text);

  let maxItemScore = 0;

  for (const cand of candidates) {
    const candWords = cand.text.split(" ");
    let matchedCount = 0;
    const matchedTargetWords = new Set();

    for (const tw of targetWords) {
      for (const cw of candWords) {
        // Word Matching Logic
        if (tw === cw) {
          matchedCount += 1;
          matchedTargetWords.add(tw);
          break;
        } 
        // Handle Initials (e.g., "J" matches "John" or "John" matches "J")
        else if (tw.length === 1 || cw.length === 1) {
          if (tw[0] === cw[0]) {
            matchedCount += 0.8; // Partial credit for initial match
            matchedTargetWords.add(tw);
            break;
          }
        }
        // Handle partial containment (e.g., "Mcnaughton" matches "Mc-naughton")
        else if (cw.includes(tw) || tw.includes(cw)) {
          matchedCount += 0.9;
          matchedTargetWords.add(tw);
          break;
        }
      }
    }

    // SCORING CALCULATION
    // Base: How many target words did we find?
    let score = (matchedCount / targetWords.length) * 75;

    // Bonus: If it's an exact string match
    if (cand.text === normalizedTarget) {
      score = 100;
    } 
    // Bonus: All words found in any order
    else if (matchedTargetWords.size === targetWords.length) {
      score += 20;
    }

    // Penalty: If the candidate has significantly more words than the target 
    // (Prevents matching "John Doe" to "John Doe Jr the Third of House Smith")
    if (candWords.length > targetWords.length + 2) {
      score -= 15;
    }

    // Apply priority multiplier
    score *= cand.priority;

    score = Math.max(0, Math.min(100, score));
    if (score > maxItemScore) maxItemScore = score;
  }

  return { url: person.url, score: maxItemScore };
}

// ← CHANGE: New function for SearchPeopleFree – parses HTML to find person link
// function extractSpfPersonUrl(ldJson, name) {
//   const data = typeof ldJson === "string" ? JSON.parse(ldJson) : ldJson;
//   console.log("Extracting SPF Person URL from LD+JSON:", data);

//   if (!Array.isArray(data)) return null;

//   for (const block of data) {
//     if (
//       block["@type"] === "ItemList" &&
//       Array.isArray(block.itemListElement) &&
//       block.itemListElement.length > 0
//     ) {
//       return block.itemListElement[0].url || null;
//     }
//   }

//   return null;
// }

function extractSpfPersonUrl(ldJson, targetName) {
  const data = typeof ldJson === "string" ? JSON.parse(ldJson) : ldJson;
  
  if (!Array.isArray(data) || !targetName || typeof targetName !== "string") {
    return { url: null, score: 0 };
  }

  // Normalize name: remove commas, trim, lowercase, collapse spaces
  const normalize = (str) => {
    if (!str) return "";
    return str.replace(/,/g, " ").trim().toLowerCase().replace(/\s+/g, " ");
  };

  const normalizedTarget = normalize(targetName);
  const targetWords = normalizedTarget.split(" ").filter(Boolean);

  if (targetWords.length === 0) {
    return { url: null, score: 0 };
  }

  let bestUrl = null;
  let bestScore = 0;

  for (const block of data) {
    if (
      block["@type"] === "ItemList" &&
      Array.isArray(block.itemListElement)
    ) {
      for (const item of block.itemListElement) {
        const name = item.name || "";
        const altName = item.alternateName || "";
        const url = item.url || null;

        const candidates = [
          { text: normalize(name), priority: 1 },        // main name
          { text: normalize(altName), priority: 2 }     // alternate often more formal/full
        ].filter(c => c.text);

        let itemMaxScore = 0;

        for (const cand of candidates) {
          const candWords = cand.text.split(" ");

          // Count how many target words appear in candidate (with partial initial match)
          let matchedCount = 0;
          const matchedTargetWords = new Set();

          for (const tw of targetWords) {
            for (const cw of candWords) {
              if (tw.length === 1 || cw.length === 1) {
                // Initials: allow single letter match
                if (tw === cw || tw.startsWith(cw) || cw.startsWith(tw)) {
                  matchedCount += 1;
                  matchedTargetWords.add(tw);
                  break;
                }
              } else if (cw.includes(tw) || tw.includes(cw)) {
                matchedCount += 1;
                matchedTargetWords.add(tw);
                break;
              }
            }
          }

          // Base score: matched parts out of total target parts
          let score = (matchedCount / targetWords.length) * 70;

          // Bonus: if candidate contains all target words in any order → big boost
          if (matchedCount === targetWords.length) {
            score += 20;
          }

          // Bonus: exact match
          if (cand.text === normalizedTarget) {
            score = 100;
          }

          // Bonus: priority for alternateName (often has middle initial/full form)
          if (cand.priority === 2) {
            score += 5;
          }

          // Penalty if many extra words (avoids overly broad matches)
          if (candWords.length > targetWords.length + 2) {
            score -= 10;
          }

          score = Math.max(0, Math.min(100, score)); // clamp 0-100

          if (score > itemMaxScore) {
            itemMaxScore = score;
          }
        }

        if (itemMaxScore > bestScore) {
          bestScore = itemMaxScore;
          bestUrl = url;
        }
      }

      // If we have a very high confidence match, we can early return
      if (bestScore >= 95) {
        return { url: bestUrl, score: Math.round(bestScore) };
      }
    }
  }

  // Final fallback: if no match above 30, return first item with low score
  if (bestScore < 30 && data.find(b => b["@type"] === "ItemList")?.itemListElement?.[0]?.url) {
    bestUrl = data.find(b => b["@type"] === "ItemList").itemListElement[0].url;
    bestScore = 20; // low confidence fallback
  }

  return { url: bestUrl, score: Math.round(bestScore) };
}


// ===== STATUS MANAGEMENT =====
function updateStatus(message, className = '', details = null) {
  currentStatus.isRunning = true;
  currentStatus.message = message;
  currentStatus.className = className;
  
  if (details) {
    currentStatus.details = { ...currentStatus.details, ...details };
  }
  
  // Broadcast to all popup instances
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
  
  console.log(`[STATUS] ${message}`, details || '');
}

function finishStatus(message, className = 'success') {
  currentStatus.isRunning = false;
  currentStatus.message = message;
  currentStatus.className = className;
  
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
  
  console.log(`[FINISHED] ${message}`);
}

// ===== MESSAGE LISTENER =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'START_SCRAPING') {
    const { workerId, batchCode } = request;
    
    if (currentStatus.isRunning) {
      sendResponse({ 
        success: false, 
        message: 'A scraping task is already running' 
      });
      return true;
    }
    
    // Start the scraping process (non-blocking)
    startScrapingProcess(workerId, batchCode);
    
    sendResponse({ 
      success: true, 
      message: 'Scraping started in background' 
    });
    
    return true;
  }
  
  if (request.type === 'GET_STATUS') {
    sendResponse({ status: currentStatus });
    return true;
  }
});

// ===== MAIN SCRAPING LOGIC (ASYNC & PARALLEL) =====
async function startScrapingProcess(workerId, batch) {
  try {
    // Reset status details
    currentStatus.details = { total: 0, completed: 0, failed: 0, inProgress: 0 };
    currentStatus.tasks = []; // Reset loaders
    updateStatus('Fetching tasks from API...');

    // === Step 1: Get tasks from API ===
    const tasks = await fetchTasksFromApi(5,batch );
    if (tasks.length === 0) { finishStatus('No tasks available', 'error'); return; }

    // --- INITIALIZE THE 5 LOADERS HERE ---
    currentStatus.tasks = tasks.map(t => ({
      taskId: t.taskId,
      status: 'processing',
      progress: 0,
      message: 'Pending...'
    }));
    // ← CHANGE: Assign platforms – first 2 FPS, next 3 SPF
    const assignedTasks = [];
    tasks.forEach((task, index) => {
      if (index < 2 && task.fastpeoplesearch_url) {
        assignedTasks.push({ ...task, platform: 'fps', startUrl: task.fastpeoplesearch_url });
      } else if (task.searchpeoplefree_url) {
        assignedTasks.push({ ...task, platform: 'spf', startUrl: task.searchpeoplefree_url });
      }
    });

    if (assignedTasks.length === 0) {
      finishStatus('No valid URLs found', 'error');
      return;
    }

    updateStatus(`Processing ${assignedTasks.length} tasks...`, '', {
      total: assignedTasks.length,
      inProgress: assignedTasks.length
    });

    // === Step 2: Process ALL tasks in parallel ===
    const taskPromises = assignedTasks.map(task => 
      processSingleTask(task, workerId)
    );

    // Wait for all tasks to complete
    const results = await Promise.allSettled(taskPromises);

    // Count successes and failures
    let successCount = 0;
    let failCount = 0;

    results.forEach(result => {
      if (result.status === 'fulfilled' && result.value.success) {
        successCount++;
      } else {
        failCount++;
      }
    });

    const finalMessage = `✓ All tasks completed! Success: ${successCount}, Failed: ${failCount}`;
    finishStatus(finalMessage, successCount > 0 ? 'success' : 'error');

  } catch (error) {
    console.error('Fatal error:', error);
    finishStatus(`Error: ${error.message}`, 'error');
  }
}

// ===== PROCESS SINGLE TASK (INDEPENDENT & ASYNC) =====
async function processSingleTask(task, workerId) {
  let tabId = null;
  const startTime = Date.now();
  console.log(`[TASK ${task.taskId}] Starting...`);
  let status=null

  try {

       // Stage 1: Initializing
    updateTaskState(task.taskId, { progress: 10, message: 'Opening tab...' });

    // Step 1: Open tab with placeholder URL
    const tab = await chrome.tabs.create({url: task.startUrl, active: false});
    tabId = tab.id;
    // Stage 2: Finding Target URL
    updateTaskState(task.taskId, { progress: 30, message: 'Locating profile...' });
    // Step 2: Wait for placeholder page to load and extract target URL
    const result = await waitAndExtractTargetUrl(tab.id, task.taskId, task.platform, task.raw_name);
    const targetUrl = result?.url || null;
    const confidence = result?.confidence || 0;
    if (!targetUrl) {
      // throw new Error('Failed to extract target URL from placeholder page');
      status="error";
    }

    console.log(`[TASK ${task.taskId}] Target URL extracted: ${targetUrl}`);

    // Step 3: Redirect to target URL
    updateTaskState(task.taskId, { progress: 60, message: 'Extracting data...' });
    await chrome.tabs.update(tab.id, { url: targetUrl });
    console.log(`[TASK ${task.taskId}] Redirected to target profile`);

    // Step 4: Wait for final page to load and extract data
    updateTaskState(task.taskId, { progress: 85, message: 'Saving results...' });
    const finalData = await waitAndExtractFinalData(tab.id, task.taskId, task.platform, task.raw_name);
    if (!finalData.extractedData) {
      status="error";
      // throw new Error('Failed to extract data from final page');
    }else{
      status="done";
    }

    console.log(`[TASK ${task.taskId}] Data extracted successfully`);

    // Step 5: Send to API
    await sendToApi(task.taskId, finalData.extractedData, targetUrl, workerId,task.platform === 'fps' ? 1 : 2,status, confidence);
    updateTaskState(task.taskId, { progress: 100, status: 'complete', message: 'Finished' });
    // Step 6: Close the tab
    try {
      await chrome.tabs.remove(tab.id);
    } catch (e) {
      console.warn(`[TASK ${task.taskId}] Failed to close tab: ${e.message}`);
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`[TASK ${task.taskId}] ✓ Completed in ${duration}s`);

    // Update completed count
    currentStatus.details.completed++;
    currentStatus.details.inProgress--;
    updateStatus(
      `Processing: ${currentStatus.details.completed}/${currentStatus.details.total} completed, ${currentStatus.details.failed} failed`,
      '',
      currentStatus.details
    );

    return { success: true, taskId: task.taskId };

  } catch (error) {
    console.error(`[TASK ${task.taskId}] ✗ Failed:`, error.message);
        // 4. Upload (Failure Path) - Ensure the DB knows this task failed
    //const emptyData = { name: '', phone_numbers: [], emails: [], best_phone_number: '', best_email: '' };
    //await sendToApi(task.taskId, emptyData, targetUrl, workerId, task.platform === 'fps' ? 1 : 2, "error", 0);
    updateTaskState(task.taskId, { progress: 100, status: 'error', message: error.message });
    // Update failed count
    currentStatus.details.failed++;
    currentStatus.details.inProgress--;
    updateStatus(
      `Processing: ${currentStatus.details.completed}/${currentStatus.details.total} completed, ${currentStatus.details.failed} failed`,
      '',
      currentStatus.details
    );

    return { success: false, taskId: task.taskId, error: error.message };
  }finally {
    if (tabId) chrome.tabs.remove(tabId).catch(() => {});
  }
}

// ===== WAIT AND EXTRACT TARGET URL (PLATFORM-AWARE) =====
// ← CHANGE: Added platform and raw_name parameters
async function waitAndExtractTargetUrl(tabId, taskId, platform, raw_name, maxWait = 60000) {
  const startTime = Date.now();
  const checkInterval = 1000;

  while (Date.now() - startTime < maxWait) {
    try {
      const [injectionResult] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const isChallenge =
            document.title.includes('Just a moment') ||
            document.querySelector('iframe[src*="challenges.cloudflare"]') ||
            document.body.innerText.includes('Checking your browser');

          if (isChallenge) return { blocked: true };

          return { html: document.documentElement.outerHTML };
        }
      });

      const result = injectionResult?.result;
      if (result?.blocked) {
        await sleep(checkInterval);
        continue;
      }

      const pageHtml = result?.html;

      if (pageHtml) {
        let personUrl = null;
        let confidence = 0;
        const ldJson = extractLdJsonFromHtml(pageHtml);         // Create a Blob from the JSON object
        if (platform === 'fps') {
          const match= extractFpsPersonUrl(ldJson, raw_name);
          personUrl = match.url;
          confidence = match.score;
          console.log("name", raw_name ,"what is this:", match," Extracted FPS URL:", personUrl, "with confidence:", confidence);
        } else if (platform === 'spf') {
          const urlwithconfig=extractSpfPersonUrl(ldJson, raw_name)
          personUrl = urlwithconfig.url;
          confidence =urlwithconfig.score;
          // console.log("name", raw_name ,"what is this:", urlwithconfig," Extracted SPF URL:", personUrl, "with confidence:", confidence);
        }

        if (personUrl) {
          const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
          console.log(`[TASK ${taskId}] Target URL found in ${elapsed}s`);
          return { url: personUrl, confidence };
        }
      }
    } catch (error) {
      console.log(`[TASK ${taskId}] Waiting...`);
    }

    await sleep(checkInterval);
  }

  // throw new Error(`Timeout extracting target URL`);
  return { url: null, confidence: 0 };
}

// ===== WAIT AND EXTRACT FINAL DATA (OPTIONAL PLATFORM TWEAK) =====
// ← CHANGE: Added platform parameter (currently same logic for both)
// ===== WAIT AND EXTRACT FINAL DATA (FIXED) =====
// ===== WAIT AND EXTRACT FINAL DATA (NO TIMEOUT FAILURES) =====
async function waitAndExtractFinalData(tabId, taskId, platform, raw_name, maxWait = 90000) {
  const startTime = Date.now();
  const checkInterval = 2000;
  const minWait = 10000;

  await sleep(minWait);

  let bestExtractedData = null;  // Store the best we have so far

  while (Date.now() - startTime < maxWait) {
    try {
      const [injectionResult] = await chrome.scripting.executeScript({
        target: { tabId },
        func: (plat) => {
          const isChallenge =
            document.title.includes('Just a moment') ||
            document.querySelector('iframe[src*="challenges.cloudflare"]') ||
            document.body.innerText.includes('Checking your browser');

          if (isChallenge) return null;

          const hasLdJson = document.querySelectorAll('script[type="application/ld+json"]').length > 0;
          const hasWamInit = plat === 'fps' ? document.documentElement.outerHTML.includes('wam.init') : true;

          if (hasLdJson && hasWamInit) {
            return document.documentElement.outerHTML;
          }
          return null;
        },
        args: [platform]
      });

      const pageHtml = injectionResult?.result;

      if (pageHtml) {
        const ldJson = extractLdJsonFromHtml(pageHtml);

        let extractedData = {
          name: '',
          phone_numbers: [],
          best_phone_number: '',
          emails: [],
          best_email: ''
        };

        if (platform === 'fps') {
          const awmJson = extractWamInitObject(pageHtml, true);
          const personLdJson = ldJson.find(item => item['@type'] === 'Person') || {};

          const nameFromAwm = awmJson 
            ? `${awmJson.fn || ''} ${awmJson.mn || ''} ${awmJson.ln || ''}`.trim().replace(/\s+/g, ' ')
            : personLdJson.name ;

          extractedData.name = nameFromAwm;
          extractedData.best_phone_number = awmJson?.phone || '';
          extractedData.best_email = awmJson?.email || '';
          extractedData.phone_numbers = extractPhoneNumbers(ldJson);

          const faqMainEntities = extractFAQPage(ldJson);
          const emailsFromFaq = emailExtractorRegx(faqMainEntities);
          if (emailsFromFaq) {
            extractedData.emails = emailsFromFaq.split(',').filter(e => e);
          }
        } 
        else if (platform === 'spf') {
          const faqMainEntities1 = extractFAQPage(ldJson);
          const emailsFromFaq = emailExtractorRegx(faqMainEntities1);
          const name = spfExtractName(ldJson);
          const phoneNumbers = spfExtractPhoneNumbers(ldJson);
          const emails = spfExtractEmails(ldJson);

          if (emailsFromFaq) {
            extractedData.best_email = emailsFromFaq;
          }


          extractedData.name = name || '';
          extractedData.phone_numbers = phoneNumbers;
          extractedData.best_phone_number = '';
          extractedData.emails = emails;
        }

        // Update best data if we have more than before
        if (
          extractedData.phone_numbers.length > (bestExtractedData?.phone_numbers.length || 0) ||
          extractedData.emails.length > (bestExtractedData?.emails.length || 0) ||
          extractedData.best_phone_number || extractedData.best_email
        ) {
          bestExtractedData = extractedData;
        }

        // If we have ANY contact info → return immediately
        if (
          extractedData.phone_numbers.length > 0 ||
          extractedData.emails.length > 0 ||
          extractedData.best_phone_number ||
          extractedData.best_email
        ) {
          const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
          console.log(`[TASK ${taskId}] Final data extracted (${platform.toUpperCase()}) in ${elapsed}s - HAS contacts`);
          return { ldJson, awmJson: platform === 'fps' ? extractWamInitObject(pageHtml, true) : null, extractedData };
        }
      }
    } catch (error) {
      console.log(`[TASK ${taskId}] Waiting for better data...`);
    }

    await sleep(checkInterval);
  }

  // === AFTER 90 SECONDS: Return whatever we have (even if empty) ===
  const finalExtractedData = bestExtractedData || {
    name: '',
    phone_numbers: [],
    best_phone_number: '',
    emails: [],
    best_email: ''
  };

  const totalElapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log(`[TASK ${taskId}] Max wait reached (${totalElapsed}s) - NO contacts found, returning empty`);

  return { 
    ldJson: [], 
    awmJson: null, 
    extractedData: finalExtractedData 
  };
}

// ===== SEND TO API (PLATFORM-AWARE) =====
// ← CHANGE: Added platformId parameter
async function sendToApi(taskId, extractedData, targetUrl, workerId, platformId, status, confidence) {
  console.log(`[TASK ${taskId}] Sending API request...`);

  const apiPayload = {
    scraped_name: extractedData.name,
    scraped_emails: Array.isArray(extractedData.emails)
      ? extractedData.emails.join(',')
      : (extractedData.emails ?? ""),
    scraped_numbers: Array.isArray(extractedData.phone_numbers)
      ? extractedData.phone_numbers.join(',')
      : (extractedData.phone_numbers ?? ""),
    best_email: extractedData.best_email,
    best_number: extractedData.best_phone_number,
    status: status,
    scrapped_from: platformId,
    scraped_by: workerId,
    profile_url: targetUrl,
    confidence: confidence
  };

  console.log(`[TASK ${taskId}] API Payload:`, apiPayload);

  const response = await fetch(`https://backendproperty.bulkscraper.cloud/api/data/${taskId}/update`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(apiPayload)
  });

  console.log(`[TASK ${taskId}] API Response status: ${response.status} ${response.statusText}`);

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`[TASK ${taskId}] API Error body:`, errorText);
    // throw new Error(`API call failed: ${response.status} ${response.statusText} - ${errorText}`);
  }

  console.log(`[TASK ${taskId}] API update successful`);
}

// ===== HELPER FUNCTIONS =====
// ===== HELPER FUNCTIONS =====
// ===== HELPER FUNCTIONS =====
// ===== HELPER FUNCTIONS =====
// ===== HELPER FUNCTIONS =====
// ===== HELPER FUNCTIONS =====
// ===== HELPER FUNCTIONS =====

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ← CHANGE: Now fetches all URL fields
async function fetchTasksFromApi(limit = 10, batchCode = null) {
  const response = await fetch(
    `https://backendproperty.bulkscraper.cloud/api/data/top/${limit}?batch=${batchCode}`,
    { method: "GET", redirect: "follow" }
  );

  if (!response.ok) throw new Error("Failed to fetch tasks from API");

  const data = await response.json();

  return data.map((item, index) => ({
    taskId: item.id ?? `task_${index}`,
    fastpeoplesearch_url: item.fastpeoplesearch_url,
    searchpeoplefree_url: item.searchpeoplefree_url,
    raw_name: item.raw_name,
  }));
}

function extractLdJsonFromHtml(htmlInput) {
  const regex = /<script\s+type=["']application\/ld\+json["']>(.*?)<\/script>/gis;
  const results = [];
  let match;

  while ((match = regex.exec(htmlInput)) !== null) {
    let rawContent = match[1].trim();

    if (rawContent) {
      try {
        rawContent = rawContent.replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "");
        rawContent = rawContent.replace(/;\s*$/, "");
        rawContent = rawContent.replace(/,(\s*[}\]])/g, "$1");

        const jsonObject = JSON.parse(rawContent);

        if (Array.isArray(jsonObject)) {
          results.push(...jsonObject);
        } else {
          results.push(jsonObject);
        }

      } catch (e) {
        console.error("Failed to parse JSON:", e.message);
      }
    }
  }
  return results;
}


function extractPhoneNumbers(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  for (const item of ldJson) {
    if (item['@type'] === 'Person' && item.telephone) {
      return Array.isArray(item.telephone) ? item.telephone : [item.telephone];
    }

    if (item['@graph'] && Array.isArray(item['@graph'])) {
      for (const graphItem of item['@graph']) {
        if (graphItem['@type'] === 'Person' && graphItem.telephone) {
          return Array.isArray(graphItem.telephone) ? graphItem.telephone : [graphItem.telephone];
        }
      }
    }
  }

  return [];
}

function extractWamInitObject(htmlContent, decodeEntities = false) {
  const match = htmlContent.match(/wam\.init\({([^}]+(?:}[^}]*)*)\}\);/s);
  if (!match) return null;

  const content = match[1];
  const result = {};

  const regex = /(\w+)\s*:\s*'([^']*)'|(\w+)\s*:\s*"([^"]*)"|(\w+)\s*:\s*(\w+(?:\s*==\s*'[^']*'\s*\?\s*\w+\s*:\s*\w+)?)/g;

  let m;
  while ((m = regex.exec(content)) !== null) {
    if (m[1]) {
      result[m[1]] = m[2];
    } else if (m[3]) {
      result[m[3]] = m[4];
    } else if (m[5]) {
      const value = m[6];
      if (value === 'true') result[m[5]] = true;
      else if (value === 'false') result[m[5]] = false;
      else if (value.includes('?')) result[m[5]] = false;
      else result[m[5]] = value;
    }
  }

  return standardizeData(result, decodeEntities);
}

function standardizeData(obj, decodeEntities) {
  if (!obj || typeof obj !== 'object') return obj;

  if (Array.isArray(obj)) {
    return obj.map(item => standardizeData(item, decodeEntities));
  }

  const result = {};

  for (const key in obj) {
    let value = obj[key];

    if (typeof value === 'string') {
      value = decodeURIComponent(value.replace(/\+/g, ' '));

      if (decodeEntities) {
        value = decodeHTMLEntities(value);
      }

      if (isEmail(value)) {
        value = value.toLowerCase().trim();
      }

      if (isPhone(value)) {
        value = standardizePhone(value);
      }
    } else if (typeof value === 'object' && value !== null) {
      value = standardizeData(value, decodeEntities);
    }

    result[key] = value;
  }

  return result;
}

function isEmail(str) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
}

function isPhone(str) {
  const cleaned = str.replace(/[\s\-\(\)\+\.]/g, '');
  return /^\d{7,15}$/.test(cleaned);
}

function standardizePhone(phone) {
  let cleaned = phone.trim();
  const hasPlus = cleaned.startsWith('+');
  cleaned = cleaned.replace(/\D/g, '');

  return hasPlus ? '+' + cleaned : cleaned;
}

function decodeHTMLEntities(str) {
  const entities = {
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&#39;': "'",
    '&apos;': "'",
    '&#x27;': "'",
    '&#x2F;': '/',
    '&nbsp;': ' '
  };

  return str.replace(/&[^;]+;/g, match => entities[match] || match);
}

console.log('Background service worker initialized - OPTIMIZED ASYNC VERSION');




// Helper function to extract FAQ main entities from LD+JSON data
function extractFAQPage(ldJsonArray) {
  console.log("Extracting FAQPage from LD+JSON:", ldJsonArray);
  
  if (!Array.isArray(ldJsonArray)) return null;
  
  for (const item of ldJsonArray) {
    // Check if this is a FAQPage type
    if (item['@type'] === 'FAQPage' && item.mainEntity) {
      return item.mainEntity; // Return the array of questions
    }
  }
  
  return null;
}


// Function to extract emails using regex from FAQ main entities
function emailExtractorRegx(mainEntity) {
    // If no mainEntity found or it's not an array, return empty string
    if (!mainEntity || !Array.isArray(mainEntity)) return "";

    const emailRegex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g;
    const emailSet = new Set();

    // Loop through each FAQ entity (Question/Answer pair)
    for (const item of mainEntity) {
        // Only target the 'text' field inside 'acceptedAnswer' as requested
        const textContent = item?.acceptedAnswer?.text;
        
        if (textContent && typeof textContent === "string") {
            const matches = textContent.match(emailRegex);
            if (matches) {
                matches.forEach(email => {
                    // Clean up and add to set to avoid duplicates
                    emailSet.add(email.toLowerCase().trim());
                });
            }
        }
    }

    // Return as a comma-separated string for your API
    return Array.from(emailSet).join(",");
}

// ===== SPF-SPECIFIC EXTRACTORS =====

function spfExtractName(ldJson) {
  if (!Array.isArray(ldJson)) return '';

  // Look for the Person block
  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (personBlock && personBlock.name) {
    return personBlock.name.trim();
  }

  return '';
}

function spfExtractPhoneNumbers(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (!personBlock || !personBlock.telephone) return [];

  // telephone can be string or array
  if (typeof personBlock.telephone === 'string') {
    return [personBlock.telephone.trim()];
  }

  if (Array.isArray(personBlock.telephone)) {
    return personBlock.telephone.map(num => num.trim()).filter(num => num);
  }

  return [];
}

function spfExtractEmails(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (!personBlock || !personBlock.email) return [];

  // email can be string or array
  if (typeof personBlock.email === 'string') {
    return [personBlock.email.trim().toLowerCase()];
  }

  if (Array.isArray(personBlock.email)) {
    return personBlock.email.map(email => email.trim().toLowerCase()).filter(email => email);
  }

  return [];
}

// ===== SPF-SPECIFIC: Extract FAQ mainEntity =====
function spfExtractFAQ(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  // Find the FAQPage block
  const faqBlock = ldJson.find(block => block['@type'] === 'FAQPage');

  if (faqBlock && Array.isArray(faqBlock.mainEntity)) {
    return faqBlock.mainEntity;
  }

  return [];
}

function updateTaskState(taskId, updates) {
  const taskIndex = currentStatus.tasks.findIndex(t => t.taskId === taskId);
  if (taskIndex > -1) {
    currentStatus.tasks[taskIndex] = { ...currentStatus.tasks[taskIndex], ...updates };
  }
  
  // Always broadcast the full state so the popup can re-render
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
}