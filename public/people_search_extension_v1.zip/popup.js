// ============================================
// POPUP SCRIPT - ENHANCED WITH USERNAME/PASSWORD AUTH
// Handles UI and communicates with background worker
// ============================================

// === DOM Elements ===
const authScreen = document.getElementById('authScreen');
const mainScreen = document.getElementById('mainScreen');
const usernameInput = document.getElementById('usernameInput');
const passwordInput = document.getElementById('passwordInput');
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const workerIdDisplay = document.getElementById('workerIdDisplay');
const authStatus = document.getElementById('authStatus');
const btn = document.getElementById('downloadBtn');
const status = document.getElementById('status');
const batchSelect = document.getElementById('batchSelect');
const totalLinksEl = document.getElementById('totalLinks');
const remainingEl = document.getElementById('remaining');
const successCountEl = document.getElementById('successCount');
const failedCountEl = document.getElementById('failedCount');

let isBatchListLoaded = false; // To prevent multiple API calls for the list
let currentWorkerId = null;

// API Configuration
const API_BASE_URL = 'https://backendproperty.bulkscraper.cloud/api'; // Replace with your actual API URL

// ===== AUTH FUNCTIONS =====
async function checkAuth() {
  const result = await chrome.storage.local.get(['workerId', 'username']);
  if (result.workerId && result.username) {
    currentWorkerId = result.workerId;
    showMainScreen(result.username);

    const savedBatch = localStorage.getItem('selectedBatchCode');
    if (savedBatch) {
        // Create temp option so UI isn't empty
        const opt = document.createElement('option');
        opt.value = savedBatch;
        opt.textContent = savedBatch;
        opt.selected = true;
        batchSelect.appendChild(opt);
        fetchBatchStatus(savedBatch);
    }
    // Check background status immediately
    checkBackgroundStatus();
  } else {
    showAuthScreen();
  }
}

function showAuthScreen() {
  authScreen.classList.add('active');
  mainScreen.classList.remove('active');
}

function showMainScreen(username) {
  authScreen.classList.remove('active');
  mainScreen.classList.add('active');
  workerIdDisplay.textContent = username || currentWorkerId;
}

async function login() {
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  if (!username || !password) {
    authStatus.textContent = 'Please enter both username and password';
    authStatus.className = 'error';
    return;
  }

  loginBtn.disabled = true;
  authStatus.textContent = 'Logging in...';
  authStatus.className = 'success';

  try {
    // Call your API to authenticate
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();

    if (response.ok && data.id) {
      // Store worker ID and username
      await chrome.storage.local.set({ 
        workerId: data.id,
        username: username 
      });
      currentWorkerId = data.id;

      authStatus.textContent = 'Login successful!';
      authStatus.className = 'success';

      // Clear inputs
      usernameInput.value = '';
      passwordInput.value = '';

      setTimeout(() => {
        showMainScreen(username);
        authStatus.textContent = '';
      }, 500);
    } else {
      authStatus.textContent = data.message || 'Invalid credentials';
      authStatus.className = 'error';
      loginBtn.disabled = false;
    }
  } catch (error) {
    console.error('Login error:', error);
    authStatus.textContent = 'Login failed. Please try again.';
    authStatus.className = 'error';
    loginBtn.disabled = false;
  }
}

async function logout() {
  await chrome.storage.local.remove(['workerId', 'username']);
  currentWorkerId = null;
  usernameInput.value = '';
  passwordInput.value = '';
  showAuthScreen();
  authStatus.textContent = '';
  status.textContent = '';
}

// ===== EVENT LISTENERS FOR AUTH =====
loginBtn.addEventListener('click', login);
logoutBtn.addEventListener('click', logout);

// Handle Enter key press
usernameInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    passwordInput.focus();
  }
});

passwordInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    login();
  }
});

// ===== SCRAPING TRIGGER =====
btn.addEventListener('click', async () => {
  if (!currentWorkerId) {
    status.textContent = 'Error: Not logged in';
    status.className = 'error';
    return;
  }

  btn.disabled = true;
  status.textContent = 'Starting parallel scraping process...';
  status.className = '';

  // Send message to background script
  chrome.runtime.sendMessage(
    { 
      type: 'START_SCRAPING', 
      workerId: currentWorkerId,
      batchCode: batchSelect.value 
    },
    (response) => {
      if (chrome.runtime.lastError) {
        status.textContent = `Error: ${chrome.runtime.lastError.message}`;
        status.className = 'error';
        btn.disabled = false;
        return;
      }

      if (!response.success) {
        status.textContent = response.message;
        status.className = 'error';
        btn.disabled = false;
      }
      // Success handling is done via STATUS_UPDATE messages
    }
  );
});

// ===== STATUS UPDATES FROM BACKGROUND =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'STATUS_UPDATE') {
    const { isRunning, message, className, details } = request.status;
    
        // Update the main header status text
    status.textContent = message;
    status.className = className;
    btn.disabled = isRunning;

    // Format message with progress details if available
    // IF tasks exist, render the individual loaders
    if (tasks && tasks.length > 0) {
      renderTaskList(tasks);
    }
    
    // Auto-refresh the bento box stats
    const savedBatch = localStorage.getItem('selectedBatchCode');
    if (savedBatch) fetchBatchStatus(savedBatch);
  }
});

// ===== CHECK BACKGROUND STATUS ON POPUP OPEN =====
async function checkBackgroundStatus() {
  chrome.runtime.sendMessage(
    { type: 'GET_STATUS' },
    (response) => {
      if (response && response.status) {
        const { isRunning, message, className, tasks } = response.status;
        status.textContent = message;
        status.className = className;
        btn.disabled = isRunning;

        if (tasks && tasks.length > 0) {
          renderTaskList(tasks);
        }
      }
    }
  );
}

// ===== BATCH MANAGEMENT FUNCTIONS =====

// Fetch Batch List only when user clicks the dropdown
batchSelect.addEventListener('mousedown', async () => {
    if (isBatchListLoaded) return;

    try {
        const response = await fetch(`${API_BASE_URL}/batch?limit=50`);
        const batches = await response.json();
        
        const currentSelection = batchSelect.value;
        batchSelect.innerHTML = '<option value="">Select a batch...</option>';

        batches.forEach(batch => {
            const opt = document.createElement('option');
            opt.value = batch.batch_code;
            opt.textContent = batch.batch_code;
            if (batch.batch_code === currentSelection) opt.selected = true;
            batchSelect.appendChild(opt);
        });

        isBatchListLoaded = true;
    } catch (err) {
        console.error("Failed to load batches:", err);
    }
});

// Handle selection change
batchSelect.addEventListener('change', (e) => {
    const selectedCode = e.target.value;
    if (!selectedCode) return;
    localStorage.setItem('selectedBatchCode', selectedCode);
    fetchBatchStatus(selectedCode);
});

// Fetch Stats for a specific batch
async function fetchBatchStatus(batchCode) {
    try {
        const response = await fetch(`${API_BASE_URL}/batch/status?batch=${batchCode}`);
        const data = await response.json();

        // data format: {"total":119,"pending":"0","done":"119","failed":"0"}
        totalLinksEl.textContent = data.total || 0;
        remainingEl.textContent = data.pending || 0;
        successCountEl.textContent = data.done || 0;
        failedCountEl.textContent = data.failed || 0;
    } catch (err) {
        console.error("Failed to fetch status:", err);
    }
}

// ===== TASK RENDERER =====
function renderTaskList(tasks) {
  const taskList = document.getElementById('taskList');
  const template = document.getElementById('taskTemplate');
  
  tasks.forEach(task => {
    // Check if we already have a loader for this task ID
    let taskEl = document.getElementById(`task-${task.taskId}`);
    
    // If it doesn't exist, create it from the template
    if (!taskEl) {
      const clone = template.content.cloneNode(true);
      taskEl = clone.querySelector('.task-item');
      taskEl.id = `task-${task.taskId}`;
      taskList.appendChild(clone);
    }
    
    // Update the ID text, Message, and Progress Bar
    taskEl.querySelector('.task-id').textContent = task.taskId;
    taskEl.querySelector('.task-message').textContent = task.message || 'Processing...';
    taskEl.querySelector('.progress-fill').style.width = `${task.progress || 0}%`;
    
    // Update the Badge status and color
    const badge = taskEl.querySelector('.task-status-badge');
    badge.textContent = task.status || 'pending';
    badge.className = `task-status-badge ${task.status || ''}`;
    
    // Add a class to the whole item for CSS styling
    taskEl.className = `task-item ${task.status || ''}`;
  });
}
// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', async () => {
  await checkAuth();
});