// F:\Imtiaj Sajin\extension\popup.js
// ============================================
// POPUP SCRIPT - ENHANCED WITH PROGRESS TRACKING
// Handles UI and communicates with background worker
// ============================================

// === DOM Elements ===
const authScreen = document.getElementById('authScreen');
const mainScreen = document.getElementById('mainScreen');
const workerIdInput = document.getElementById('workerIdInput');
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const workerIdDisplay = document.getElementById('workerIdDisplay');
const authStatus = document.getElementById('authStatus');
const btn = document.getElementById('downloadBtn');
const status = document.getElementById('status');

let currentWorkerId = null;

// ===== AUTH FUNCTIONS =====
async function checkAuth() {
  const result = await chrome.storage.local.get(['workerId']);
  if (result.workerId) {
    currentWorkerId = result.workerId;
    showMainScreen();
    // Check background status immediately
    checkBackgroundStatus();
  } else {
    showAuthScreen();
  }
}

function showAuthScreen() {
  authScreen.classList.add('active');
  mainScreen.classList.remove('active');
}

function showMainScreen() {
  authScreen.classList.remove('active');
  mainScreen.classList.add('active');
  workerIdDisplay.textContent = currentWorkerId;
}

async function login() {
  const workerId = workerIdInput.value.trim();

  if (!workerId) {
    authStatus.textContent = 'Please enter a Worker ID';
    authStatus.className = 'error';
    return;
  }

  await chrome.storage.local.set({ workerId: workerId });
  currentWorkerId = workerId;

  authStatus.textContent = 'Login successful!';
  authStatus.className = 'success';

  setTimeout(() => {
    showMainScreen();
    authStatus.textContent = '';
  }, 500);
}

async function logout() {
  await chrome.storage.local.remove(['workerId']);
  currentWorkerId = null;
  workerIdInput.value = '';
  showAuthScreen();
}

// ===== EVENT LISTENERS FOR AUTH =====
loginBtn.addEventListener('click', login);
logoutBtn.addEventListener('click', logout);

workerIdInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    login();
  }
});

// ===== SCRAPING TRIGGER =====
btn.addEventListener('click', async () => {
  if (!currentWorkerId) {
    status.textContent = 'Error: Not logged in';
    status.className = 'error';
    return;
  }

  btn.disabled = true;
  status.textContent = 'Starting parallel scraping process...';
  status.className = '';

  // Send message to background script
  chrome.runtime.sendMessage(
    { 
      type: 'START_SCRAPING', 
      workerId: currentWorkerId 
    },
    (response) => {
      if (chrome.runtime.lastError) {
        status.textContent = `Error: ${chrome.runtime.lastError.message}`;
        status.className = 'error';
        btn.disabled = false;
        return;
      }

      if (!response.success) {
        status.textContent = response.message;
        status.className = 'error';
        btn.disabled = false;
      }
      // Success handling is done via STATUS_UPDATE messages
    }
  );
});

// ===== STATUS UPDATES FROM BACKGROUND =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'STATUS_UPDATE') {
    const { isRunning, message, className, details } = request.status;
    
    // Format message with progress details if available
    let displayMessage = message;
    if (details && details.total > 0) {
      displayMessage = `${message}\n[${details.completed}/${details.total} completed, ${details.failed} failed]`;
    }
    
    status.textContent = displayMessage;
    status.className = className;
    btn.disabled = isRunning;
  }
});

// ===== CHECK BACKGROUND STATUS ON POPUP OPEN =====
async function checkBackgroundStatus() {
  chrome.runtime.sendMessage(
    { type: 'GET_STATUS' },
    (response) => {
      if (chrome.runtime.lastError) {
        console.error('Failed to get status:', chrome.runtime.lastError);
        return;
      }

      if (response && response.status) {
        const { isRunning, message, className, details } = response.status;
        
        // Format message with progress details if available
        let displayMessage = message;
        if (details && details.total > 0) {
          displayMessage = `${message}\n[${details.completed}/${details.total} completed, ${details.failed} failed]`;
        }
        
        status.textContent = displayMessage;
        status.className = className;
        btn.disabled = isRunning;
      }
    }
  );
}

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', async () => {
  await checkAuth();
});