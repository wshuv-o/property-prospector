// ============================================
// POPUP SCRIPT - FIXED WITH AUTOPILOT TOGGLE
// Handles UI and communicates with background worker
// ============================================

// === DOM Elements ===
const authScreen = document.getElementById('authScreen');
const mainScreen = document.getElementById('mainScreen');
const usernameInput = document.getElementById('usernameInput');
const passwordInput = document.getElementById('passwordInput');
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const workerIdDisplay = document.getElementById('workerIdDisplay');
const authStatus = document.getElementById('authStatus');
const btn = document.getElementById('downloadBtn');
const status = document.getElementById('status');
const batchSelect = document.getElementById('batchSelect');
const totalLinksEl = document.getElementById('totalLinks');
const remainingEl = document.getElementById('remaining');
const successCountEl = document.getElementById('successCount');
const failedCountEl = document.getElementById('failedCount');
const autopilotToggle = document.getElementById('autopilotToggle');
const autopilotStatus = document.getElementById('autopilotStatus');

let isBatchListLoaded = false;
let currentWorkerId = null;
let statsRefreshInterval = null;

// API Configuration
const API_BASE_URL = 'https://backendproperty.bulkscraper.cloud/api';

// ===== AUTH FUNCTIONS =====
async function checkAuth() {
  const result = await chrome.storage.local.get(['workerId', 'username', 'autopilotEnabled']);
  if (result.workerId && result.username) {
    currentWorkerId = result.workerId;
    showMainScreen(result.username);

    // Restore autopilot state
    if (result.autopilotEnabled !== undefined) {
      autopilotToggle.checked = result.autopilotEnabled;
      updateAutopilotUI(result.autopilotEnabled);
    }

    const savedBatch = localStorage.getItem('selectedBatchCode');
    if (savedBatch) {
      const opt = document.createElement('option');
      opt.value = savedBatch;
      opt.textContent = savedBatch;
      opt.selected = true;
      batchSelect.appendChild(opt);
      fetchBatchStatus(savedBatch);
      startStatsRefresh(savedBatch);
    }
    
    checkBackgroundStatus();
  } else {
    showAuthScreen();
  }
}

function showAuthScreen() {
  authScreen.classList.add('active');
  mainScreen.classList.remove('active');
  stopStatsRefresh();
}

function showMainScreen(username) {
  authScreen.classList.remove('active');
  mainScreen.classList.add('active');
  workerIdDisplay.textContent = username || currentWorkerId;
}

async function login() {
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  if (!username || !password) {
    authStatus.textContent = 'Please enter both username and password';
    authStatus.className = 'error';
    return;
  }

  loginBtn.disabled = true;
  authStatus.textContent = 'Logging in...';
  authStatus.className = 'success';

  try {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();

    if (response.ok && data.id) {
      await chrome.storage.local.set({ 
        workerId: data.id,
        username: username 
      });
      currentWorkerId = data.id;

      authStatus.textContent = 'Login successful!';
      authStatus.className = 'success';

      usernameInput.value = '';
      passwordInput.value = '';

      setTimeout(() => {
        showMainScreen(username);
        authStatus.textContent = '';
      }, 500);
    } else {
      authStatus.textContent = data.message || 'Invalid credentials';
      authStatus.className = 'error';
      loginBtn.disabled = false;
    }
  } catch (error) {
    console.error('Login error:', error);
    authStatus.textContent = 'Login failed. Please try again.';
    authStatus.className = 'error';
    loginBtn.disabled = false;
  }
}

async function logout() {
  await chrome.storage.local.remove(['workerId', 'username']);
  currentWorkerId = null;
  usernameInput.value = '';
  passwordInput.value = '';
  showAuthScreen();
  authStatus.textContent = '';
  status.textContent = '';
  stopStatsRefresh();
}

// ===== EVENT LISTENERS FOR AUTH =====
loginBtn.addEventListener('click', login);
logoutBtn.addEventListener('click', logout);

usernameInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    passwordInput.focus();
  }
});

passwordInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    login();
  }
});

// ===== AUTOPILOT TOGGLE =====
if (autopilotToggle) {
  autopilotToggle.addEventListener('change', async (e) => {
    const enabled = e.target.checked;
    
    try {
      // Save to storage
      await chrome.storage.local.set({ autopilotEnabled: enabled });
      
      // Notify background script
      chrome.runtime.sendMessage({
        type: 'TOGGLE_AUTOPILOT',
        enabled: enabled
      }, (response) => {
        if (response?.success) {
          updateAutopilotUI(enabled);
          console.log(`Autopilot ${enabled ? 'enabled' : 'disabled'}`);
        } else {
          // Revert toggle if failed
          autopilotToggle.checked = !enabled;
        }
      });
    } catch (error) {
      console.error('Failed to toggle autopilot:', error);
      autopilotToggle.checked = !enabled;
    }
  });
}

function updateAutopilotUI(enabled) {
  if (autopilotStatus) {
    autopilotStatus.textContent = enabled ? 'ON' : 'OFF';
    autopilotStatus.className = enabled ? 'autopilot-on' : 'autopilot-off';
  }
}

// ===== SCRAPING TRIGGER =====
btn.addEventListener('click', async () => {
  if (!currentWorkerId) {
    status.textContent = 'Error: Not logged in';
    status.className = 'error';
    return;
  }

  const selectedBatch = batchSelect.value;
  if (!selectedBatch) {
    status.textContent = 'Error: Please select a batch';
    status.className = 'error';
    return;
  }

  btn.disabled = true;
  status.textContent = 'Starting parallel scraping process...';
  status.className = '';

  // Show 5 empty loaders immediately
  const taskList = document.getElementById('taskList');
  taskList.innerHTML = '';
  const tempTasks = Array.from({length: 5}, (_, i) => ({
    taskId: '...', 
    status: 'pending', 
    progress: 0, 
    message: 'Fetching from queue...'
  }));
  renderTaskList(tempTasks);

  chrome.runtime.sendMessage(
    { 
      type: 'START_SCRAPING', 
      workerId: currentWorkerId,
      batchCode: selectedBatch
    },
    (response) => {
      if (chrome.runtime.lastError) {
        status.textContent = `Error: ${chrome.runtime.lastError.message}`;
        status.className = 'error';
        btn.disabled = false;
        return;
      }

      if (!response?.success) {
        status.textContent = response?.message || 'Failed to start';
        status.className = 'error';
        btn.disabled = false;
      }
    }
  );
});

// ===== LOW CONF MODE TRIGGER =====
const lowConfBtn = document.getElementById('lowConfBtn');

if (lowConfBtn) {
  lowConfBtn.addEventListener('click', async () => {
    if (!currentWorkerId) {
      status.textContent = 'Error: Not logged in';
      status.className = 'error';
      return;
    }

    const selectedBatch = batchSelect.value;
    if (!selectedBatch) {
      status.textContent = 'Error: Please select a batch';
      status.className = 'error';
      return;
    }

    if (lowConfBtn.disabled) return;

    lowConfBtn.disabled = true;
    status.textContent = 'LOW CONF Mode: Starting experimental scraping...';
    status.className = 'warning';

    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';
    const tempTasks = Array.from({length: 5}, (_, i) => ({
      taskId: '...',
      status: 'pending',
      progress: 0,
      message: 'LOW CONF Mode - Queueing...'
    }));
    renderTaskList(tempTasks);

    chrome.runtime.sendMessage({
      type: 'LOW_CONF_MODE',
      workerId: currentWorkerId,
      batchCode: selectedBatch
    }, (response) => {
      if (chrome.runtime.lastError || !response?.success) {
        status.textContent = response?.message || 'LOW CONF failed to start';
        status.className = 'error';
        lowConfBtn.disabled = false;
        return;
      }
      status.textContent = 'LOW CONF Mode running (HTML-based matching)';
      status.className = 'warning';
    });
  });
}

// ===== STATUS UPDATES FROM BACKGROUND =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'STATUS_UPDATE') {
    const { 
      isRunning, 
      message = 'Ready', 
      className = '', 
      tasks = [], 
      autopilot = false 
    } = request.status;

    // Main status with autopilot indicator
    let displayMessage = message;
    if (autopilot) {
      displayMessage = `🔄 ${message}`;
    }
    status.textContent = displayMessage;
    status.className = className;

    // Button states
    btn.disabled = isRunning;
    if (lowConfBtn) lowConfBtn.disabled = isRunning;

    // Update task loaders
    if (tasks.length > 0) {
      renderTaskList(tasks);
    } else if (!isRunning) {
      // Clear task list when batch is complete
      document.getElementById('taskList').innerHTML = '';
    }

    // Refresh stats
    const savedBatch = localStorage.getItem('selectedBatchCode');
    if (savedBatch) {
      fetchBatchStatus(savedBatch);
    }
  }
});

// ===== CHECK BACKGROUND STATUS ON POPUP OPEN =====
async function checkBackgroundStatus() {
  chrome.runtime.sendMessage(
    { type: 'GET_STATUS' },
    (response) => {
      if (response?.status) {
        const { isRunning, message, className, tasks, autopilot } = response.status;
        
        let displayMessage = message;
        if (autopilot) displayMessage = `🔄 ${message}`;
        
        status.textContent = displayMessage;
        status.className = className;
        btn.disabled = isRunning;
        if (lowConfBtn) lowConfBtn.disabled = isRunning;

        if (tasks && tasks.length > 0) {
          renderTaskList(tasks);
        }
      }
    }
  );
}

// ===== BATCH MANAGEMENT FUNCTIONS =====

// Fetch Batch List when dropdown is clicked
batchSelect.addEventListener('mousedown', async () => {
  if (isBatchListLoaded) return;

  try {
    const response = await fetch(`${API_BASE_URL}/batch?limit=50`);
    if (!response.ok) throw new Error('Failed to fetch batches');
    
    const batches = await response.json();
    
    const currentSelection = batchSelect.value;
    batchSelect.innerHTML = '<option value="">Select a batch...</option>';

    batches.forEach(batch => {
      const opt = document.createElement('option');
      opt.value = batch.batch_code;
      opt.textContent = batch.batch_code;
      if (batch.batch_code === currentSelection) opt.selected = true;
      batchSelect.appendChild(opt);
    });

    isBatchListLoaded = true;
  } catch (err) {
    console.error("Failed to load batches:", err);
    status.textContent = 'Failed to load batches';
    status.className = 'error';
  }
});

// Handle batch selection change
batchSelect.addEventListener('change', (e) => {
  const selectedCode = e.target.value;
  if (!selectedCode) {
    stopStatsRefresh();
    return;
  }
  
  localStorage.setItem('selectedBatchCode', selectedCode);
  fetchBatchStatus(selectedCode);
  startStatsRefresh(selectedCode);
});

// Fetch Stats for a specific batch
async function fetchBatchStatus(batchCode) {
  try {
    const response = await fetch(`${API_BASE_URL}/batch/status?batch=${batchCode}`);
    if (!response.ok) throw new Error('Failed to fetch status');
    
    const data = await response.json();
    updateStatsUI(data);
    await chrome.storage.local.set({ lastStats: data });
  } catch (err) {
    console.error("Failed to fetch status:", err);
  }
}

// Auto-refresh stats every 10 seconds when running
function startStatsRefresh(batchCode) {
  stopStatsRefresh();
  statsRefreshInterval = setInterval(() => {
    fetchBatchStatus(batchCode);
  }, 10000); // Refresh every 10 seconds
}

function stopStatsRefresh() {
  if (statsRefreshInterval) {
    clearInterval(statsRefreshInterval);
    statsRefreshInterval = null;
  }
}

// Update UI with stats
function updateStatsUI(data) {
  totalLinksEl.textContent = data.total || 0;
  remainingEl.textContent = data.pending || 0;
  successCountEl.textContent = data.done || 0;
  failedCountEl.textContent = data.failed || 0;
}

// ===== TASK RENDERER =====
function renderTaskList(tasks) {
  const taskList = document.getElementById('taskList');
  const template = document.getElementById('taskTemplate');
  
  // Remove tasks that are no longer in the list
  const currentTaskIds = new Set(tasks.map(t => t.taskId));
  const existingTasks = taskList.querySelectorAll('.task-item');
  existingTasks.forEach(taskEl => {
    const taskId = taskEl.id.replace('task-', '');
    if (!currentTaskIds.has(taskId)) {
      taskEl.remove();
    }
  });
  
  // Update or create task elements
  tasks.forEach(task => {
    let taskEl = document.getElementById(`task-${task.taskId}`);
    
    if (!taskEl) {
      const clone = template.content.cloneNode(true);
      taskEl = clone.querySelector('.task-item');
      taskEl.id = `task-${task.taskId}`;
      taskList.appendChild(clone);
      taskEl = document.getElementById(`task-${task.taskId}`);
    }
    
    // Update content
    taskEl.querySelector('.task-id').textContent = task.taskId;
    taskEl.querySelector('.task-message').textContent = task.message || 'Processing...';
    taskEl.querySelector('.progress-fill').style.width = `${task.progress || 0}%`;
    
    // Update badge
    const badge = taskEl.querySelector('.task-status-badge');
    badge.textContent = task.status || 'pending';
    badge.className = `task-status-badge ${task.status || ''}`;
    
    // Update item class
    taskEl.className = `task-item ${task.status || ''}`;
  });
}

// ===== CLEANUP ON POPUP CLOSE =====
window.addEventListener('beforeunload', () => {
  stopStatsRefresh();
});

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', async () => {
  // Load cached stats immediately
  const cache = await chrome.storage.local.get(['lastStats']);
  if (cache.lastStats) {
    updateStatsUI(cache.lastStats);
  }
  
  await checkAuth();
});