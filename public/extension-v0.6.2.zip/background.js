// ============================================
// BACKGROUND SERVICE WORKER - FIXED VERSION
// Handles all scraping operations with proper error handling
// ============================================

// Keep-alive: Alarm + Port
chrome.alarms.create('keepAlive', { periodInMinutes: 0.25 });

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'keepAlive') {
    // Minimal activity
  }
});

let keepAlivePort = null;
function startKeepAlivePort() {
  if (keepAlivePort) return;
  keepAlivePort = chrome.runtime.connect({ name: 'keepAlive' });
  keepAlivePort.onDisconnect.addListener(() => {
    keepAlivePort = null;
    if (currentStatus.isRunning || autopilotEnabled) {
      setTimeout(startKeepAlivePort, 1000);
    }
  });
}
function stopKeepAlivePort() {
  if (keepAlivePort) {
    keepAlivePort.disconnect();
    keepAlivePort = null;
  }
}
function ensureKeepAlive() {
  if (currentStatus.isRunning || autopilotEnabled) {
    startKeepAlivePort();
  } else {
    stopKeepAlivePort();
  }
}

const CONFIDENCE_THRESHOLD = 70;

let autopilotEnabled = false;
let currentBatchCode = null;
let isFetchingNextBatch = false;
let isProcessingBatch = false; // NEW: Prevent overlapping batches

let currentStatus = {
  isRunning: false,
  message: 'Ready to start',
  className: '',
  tasks: [],
  details: {
    total: 0,
    completed: 0,
    failed: 0,
    inProgress: 0
  }
};

function extractFpsPersonUrl(ldJsonArray, targetName) {
  if (!Array.isArray(ldJsonArray) || !targetName || typeof targetName !== "string") {
    return { url: null, confidence: 0 };
  }

  const normalize = (str) => {
    if (!str) return "";
    return str.toLowerCase()
      .replace(/[^a-z0-9 ]/g, " ")
      .trim()
      .replace(/\s+/g, " ");
  };

  const normalizedTarget = normalize(targetName);
  const targetWords = normalizedTarget.split(" ").filter(Boolean);

  if (targetWords.length === 0) return { url: null, confidence: 0 };

  let bestUrl = null;
  let bestScore = 0;

  for (const item of ldJsonArray) {
    if (item["@type"] === "Person") {
      const result = evaluateFpsPerson(item, normalizedTarget, targetWords, normalize);
      
      if (result.confidence > bestScore) {
        bestScore = result.confidence;
        bestUrl = result.url;
      }
    }
  }
  return { url: bestUrl, confidence: Math.round(bestScore) };
}

function evaluateFpsPerson(person, normalizedTarget, targetWords, normalize) {
  const mainName = normalize(person.name || "");
  
  const aliases = Array.isArray(person.additionalName) 
    ? person.additionalName.map(normalize) 
    : (person.additionalName ? [normalize(person.additionalName)] : []);

  const candidates = [
    { text: mainName, priority: 1.0 },
    ...aliases.map(a => ({ text: a, priority: 0.9 }))
  ].filter(c => c.text);

  let maxItemScore = 0;

  for (const cand of candidates) {
    const candWords = cand.text.split(" ");
    let matchedCount = 0;
    const matchedTargetWords = new Set();

    for (const tw of targetWords) {
      for (const cw of candWords) {
        if (tw === cw) {
          matchedCount += 1;
          matchedTargetWords.add(tw);
          break;
        } 
        else if (tw.length === 1 || cw.length === 1) {
          if (tw[0] === cw[0]) {
            matchedCount += 0.8;
            matchedTargetWords.add(tw);
            break;
          }
        }
        else if (cw.includes(tw) || tw.includes(cw)) {
          matchedCount += 0.9;
          matchedTargetWords.add(tw);
          break;
        }
      }
    }

    let score = (matchedCount / targetWords.length) * 75;

    if (cand.text === normalizedTarget) {
      score = 100;
    } 
    else if (matchedTargetWords.size === targetWords.length) {
      score += 20;
    }

    if (candWords.length > targetWords.length + 2) {
      score -= 15;
    }

    score *= cand.priority;
    score = Math.max(0, Math.min(100, score));
    if (score > maxItemScore) maxItemScore = score;
  }

  return { url: person.url, confidence: maxItemScore };
}

function extractSpfPersonUrl(ldJson, targetName) {
  const data = typeof ldJson === "string" ? JSON.parse(ldJson) : ldJson;
  
  if (!Array.isArray(data) || !targetName || typeof targetName !== "string") {
    return { url: null, confidence: 0 };
  }

  const normalize = (str) => {
    if (!str) return "";
    return str.replace(/,/g, " ").trim().toLowerCase().replace(/\s+/g, " ");
  };

  const normalizedTarget = normalize(targetName);
  const targetWords = normalizedTarget.split(" ").filter(Boolean);

  if (targetWords.length === 0) {
    return { url: null, confidence: 0 };
  }

  let bestUrl = null;
  let bestScore = 0;

  for (const block of data) {
    if (
      block["@type"] === "ItemList" &&
      Array.isArray(block.itemListElement)
    ) {
      for (const item of block.itemListElement) {
        const name = item.name || "";
        const altName = item.alternateName || "";
        const url = item.url || null;

        const candidates = [
          { text: normalize(name), priority: 1 },
          { text: normalize(altName), priority: 2 }
        ].filter(c => c.text);

        let itemMaxScore = 0;

        for (const cand of candidates) {
          const candWords = cand.text.split(" ");

          let matchedCount = 0;
          const matchedTargetWords = new Set();

          for (const tw of targetWords) {
            for (const cw of candWords) {
              if (tw.length === 1 || cw.length === 1) {
                if (tw === cw || tw.startsWith(cw) || cw.startsWith(tw)) {
                  matchedCount += 1;
                  matchedTargetWords.add(tw);
                  break;
                }
              } else if (cw.includes(tw) || tw.includes(cw)) {
                matchedCount += 1;
                matchedTargetWords.add(tw);
                break;
              }
            }
          }

          let score = (matchedCount / targetWords.length) * 70;

          if (matchedCount === targetWords.length) {
            score += 20;
          }

          if (cand.text === normalizedTarget) {
            score = 100;
          }

          if (cand.priority === 2) {
            score += 5;
          }

          if (candWords.length > targetWords.length + 2) {
            score -= 10;
          }

          score = Math.max(0, Math.min(100, score));

          if (score > itemMaxScore) {
            itemMaxScore = score;
          }
        }

        if (itemMaxScore > bestScore) {
          bestScore = itemMaxScore;
          bestUrl = url;
        }
      }

      if (bestScore >= 95) {
        return { url: bestUrl, confidence: Math.round(bestScore) };
      }
    }
  }

  if (bestScore < 30 && data.find(b => b["@type"] === "ItemList")?.itemListElement?.[0]?.url) {
    bestUrl = data.find(b => b["@type"] === "ItemList").itemListElement[0].url;
    bestScore = 20;
  }

  return { url: bestUrl, confidence: Math.round(bestScore) };
}

// ===== STATUS MANAGEMENT =====
function updateStatus(message, className = '', details = null) {
  currentStatus.isRunning = true;
  currentStatus.message = message;
  currentStatus.className = className;
  currentStatus.autopilot = autopilotEnabled;
  
  if (details) {
    currentStatus.details = { ...currentStatus.details, ...details };
  }
  
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
  
  console.log(`[STATUS] ${message}`, details || '');
  ensureKeepAlive();
}

function finishStatus(message, className = 'success') {
  currentStatus.isRunning = false;
  currentStatus.message = message;
  currentStatus.className = className;
  currentStatus.autopilot = autopilotEnabled;
  
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
  
  console.log(`[FINISHED] ${message}`);
  ensureKeepAlive();
}

// ===== MESSAGE LISTENER =====
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'START_SCRAPING') {
    const { workerId, batchCode } = request;
    
    if (currentStatus.isRunning || isProcessingBatch) {
      sendResponse({ 
        success: false, 
        message: 'A scraping task is already running' 
      });
      return true;
    }
    
    startScrapingProcess(workerId, batchCode);
    
    sendResponse({ 
      success: true, 
      message: 'Scraping started in background' 
    });
    
    return true;
  }
  
  if (request.type === 'LOW_CONF_MODE') {
    const { workerId, batchCode } = request;

    if (currentStatus.isRunning || isProcessingBatch) {
      sendResponse({ 
        success: false, 
        message: 'A task is already running' 
      });
      return true;
    }

    startLowConfProcess(workerId, batchCode);
    
    sendResponse({ 
      success: true, 
      message: 'LOW CONF mode started' 
    });
    
    return true;
  }
  
  if (request.type === 'TOGGLE_AUTOPILOT') {
    autopilotEnabled = request.enabled;
    currentStatus.autopilot = autopilotEnabled;
    chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', status: currentStatus }).catch(() => {});
    ensureKeepAlive();
    sendResponse({ success: true });
    return true;
  }
  
  if (request.type === 'GET_STATUS') {
    sendResponse({ status: currentStatus });
    return true;
  }
});

// ===== MAIN SCRAPING LOGIC (FIXED) =====
async function startScrapingProcess(workerId, batch) {
  if (isProcessingBatch) {
    console.log('[BATCH] Already processing, skipping...');
    return;
  }

  isProcessingBatch = true;
  currentBatchCode = batch;
  currentStatus.details = { total: 0, completed: 0, failed: 0, inProgress: 0 };
  currentStatus.tasks = [];
  currentStatus.autopilot = autopilotEnabled;
  
  try {
    updateStatus('Fetching tasks from API...');

    const tasks = await fetchTasksFromApi(5, batch);
    if (tasks.length === 0) {
      finishStatus('No tasks available', 'error');
      isProcessingBatch = false;
      checkForNextBatch(workerId);
      return;
    }

    currentStatus.tasks = tasks.map(t => ({
      taskId: t.taskId,
      status: 'pending',
      progress: 0,
      message: 'Queued...'
    }));

    const assignedTasks = [];
    tasks.forEach((task, i) => {
      let primary = i < 2 ? 'fps' : 'spf';
      let alt = primary === 'fps' ? 'spf' : 'fps';
      let primaryUrl = primary === 'fps' ? task.fastpeoplesearch_url : task.searchpeoplefree_url;
      let altUrl = alt === 'fps' ? task.fastpeoplesearch_url : task.searchpeoplefree_url;

      if (primaryUrl) {
        assignedTasks.push({ ...task, platform: primary, startUrl: primaryUrl, altPlatform: alt, altUrl });
      }
    });

    if (assignedTasks.length === 0) {
      finishStatus('No valid URLs found', 'error');
      isProcessingBatch = false;
      checkForNextBatch(workerId);
      return;
    }

    currentStatus.details.total = assignedTasks.length;
    currentStatus.details.inProgress = assignedTasks.length;
    updateStatus(`Processing ${assignedTasks.length} tasks...`, '', currentStatus.details);

    const promises = assignedTasks.map(task => processSingleTask(task, workerId));
    await Promise.allSettled(promises);

    // All tasks finished
    isProcessingBatch = false;
    
    // Final status update
    const allDone = currentStatus.details.completed + currentStatus.details.failed;
    finishStatus(`Batch complete: ${currentStatus.details.completed} succeeded, ${currentStatus.details.failed} failed`, 'success');
    
    // Check for next batch AFTER finishing
    setTimeout(() => checkForNextBatch(workerId), 1000);
    
  } catch (error) {
    console.error('[BATCH] Fatal error:', error);
    finishStatus(`Error: ${error.message}`, 'error');
    isProcessingBatch = false;
    setTimeout(() => checkForNextBatch(workerId), 1000);
  }
}

// ===== LOW CONF MODE =====
async function startLowConfProcess(workerId, batchCode) {
  if (isProcessingBatch) {
    console.log('[LOWCONF]Already processing, skipping...');
    return;
  }

  isProcessingBatch = true;
  
  try {
    currentStatus.details = { total: 0, completed: 0, failed: 0, inProgress: 0 };
    currentStatus.tasks = [];
    updateStatus('LOW CONF Mode: Fetching tasks...');
 
    const tasks = await fetchTasksFromApi(5, batchCode, true);
    if (tasks.length === 0) { 
      finishStatus('No tasks available', 'error');
      isProcessingBatch = false;
      return; 
    }

    currentStatus.tasks = tasks.map(t => ({
      taskId: t.taskId,
      status: 'processing',
      progress: 0,
      message: 'Pending...'
    }));

    const assignedTasks = tasks.map(task => ({
      ...task,
      startUrl: task.fastpeoplesearch_url || task.searchpeoplefree_url,
    })).filter(t => t.startUrl);

    if (assignedTasks.length === 0) {
      finishStatus('No valid URLs found', 'error');
      isProcessingBatch = false;
      return;
    }

    updateStatus(`LOW CONF: Processing ${assignedTasks.length} tasks...`, '', {
      total: assignedTasks.length,
      inProgress: assignedTasks.length
    });

    const taskPromises = assignedTasks.map(task => 
      processSingleTaskLowConf(task, workerId)
    );

    await Promise.allSettled(taskPromises);

    const successCount = currentStatus.details.completed;
    const failCount = currentStatus.details.failed;

    finishStatus(`LOW CONF Complete! Success: ${successCount}, Failed: ${failCount}`, 'success');
    isProcessingBatch = false;

  } catch (error) {
    console.error('[LOWCONF]Fatal error:', error);
    finishStatus(`LOW CONF Error: ${error.message}`, 'error');
    isProcessingBatch = false;
  }
}

// ===== LOW CONF SINGLE TASK =====
async function processSingleTaskLowConf(task, workerId) {
  let tabId = null;

  try {
    updateTaskState(task.taskId, { progress: 10, message: 'Opening...', status: 'processing' });

    const tab = await chrome.tabs.create({ url: task.startUrl, active: false });
    tabId = tab.id;

    updateTaskState(task.taskId, { progress: 30, message: 'Scanning names...' });

    const result = await waitAndExtractTargetUrlLowConf(tab.id, task.taskId, task.raw_name);

    if (!result?.url || result.confidence < 30) {
      throw new Error(`No confident match found (confidence: ${result?.confidence || 0})`);
    }

    console.log(`[LOWCONF ${task.taskId}] Best URL: ${result.url} (confidence: ${result.confidence})`);

    updateTaskState(task.taskId, { progress: 60, message: 'Going to profile...' });
    await chrome.tabs.update(tab.id, { url: result.url });

    updateTaskState(task.taskId, { progress: 85, message: 'Extracting data...' });
    const finalData = await waitAndExtractFinalData(tab.id, task.taskId, 'fps', task.raw_name);

    const status = finalData.extractedData && 
      (finalData.extractedData.phone_numbers.length > 0 || 
       finalData.extractedData.emails.length > 0 ||
       finalData.extractedData.best_phone_number ||
       finalData.extractedData.best_email) 
      ? "done" : "error";

    await sendToApi(task.taskId, finalData.extractedData || {}, result.url, workerId, 1, status, result.confidence);

    updateTaskState(task.taskId, { progress: 100, status: 'complete', message: 'Done' });

    currentStatus.details.completed++;
    currentStatus.details.inProgress--;
    updateStatus(`LOW CONF: ${currentStatus.details.completed}/${currentStatus.details.total} done`, '', currentStatus.details);

    return { success: true };

  } catch (error) {
    console.error(`[LOWCONF ${task.taskId}] Failed:`, error.message);
    const emptyData = { name: '', phone_numbers: [], emails: [], best_phone_number: '', best_email: '' };
    await sendToApi(task.taskId, emptyData, task.startUrl, workerId, 1, "error", 0);
    updateTaskState(task.taskId, { progress: 100, status: 'error', message: error.message.substring(0, 50) });
    
    currentStatus.details.failed++;
    currentStatus.details.inProgress--;
    updateStatus(`LOW CONF: ${currentStatus.details.failed} failed`, '', currentStatus.details);

    return { success: false, error: error.message };
  } finally {
    if (tabId) {
      try {
        await chrome.tabs.remove(tabId);
      } catch (e) {
        console.log(`[LOWCONF ${task.taskId}] Tab already closed`);
      }
    }
  }
}

// ===== LOW CONF URL EXTRACTOR =====
async function waitAndExtractTargetUrlLowConf(tabId, taskId, raw_name, maxWait = 60000) {
  const startTime = Date.now();
  const checkInterval = 1000;

  while (Date.now() - startTime < maxWait) {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const isChallenge = document.title.includes('Just a moment') ||
            document.querySelector('iframe[src*="challenges.cloudflare"]');
          if (isChallenge) return { blocked: true };
          return { html: document.documentElement.outerHTML };
        }
      });

      if (result?.result?.blocked) {
        await sleep(checkInterval);
        continue;
      }

      const html = result?.result?.html;
      if (html) {
        const match = findProfileUrlWithConfidence(html, raw_name);
        if (match.url && match.confidence >= 30) {
          return match;
        }
      }
    } catch (e) {
      console.log(`[LOWCONF ${taskId}] Tab not ready, waiting...`);
    }
    await sleep(checkInterval);
  }

  return { url: null, confidence: 0, displayedName: '' };
}

// ===== PROCESS SINGLE TASK (FIXED) =====
async function processSingleTask(task, workerId) {
  let tabId = null;
  let targetUrl = null;
  let confidence = 0;
  let currentPlatform = task.platform;
  let currentPlatformId = currentPlatform === 'fps' ? 1 : 2;

  try {
    updateTaskState(task.taskId, { progress: 10, message: 'Opening...', status: 'processing' });

    const tab = await chrome.tabs.create({ url: task.startUrl, active: false });
    tabId = tab.id;

    updateTaskState(task.taskId, { progress: 30, message: 'Finding profile...' });

    let result = await waitAndExtractTargetUrl(tab.id, task.taskId, task.platform, task.raw_name);
    targetUrl = result.url;
    confidence = result.confidence;

    // Fallback if needed
    if ((!targetUrl || confidence < CONFIDENCE_THRESHOLD) && task.altUrl) {
      console.log(`[TASK ${task.taskId}] Fallback to ${task.altPlatform}`);
      updateTaskState(task.taskId, { progress: 40, message: 'Trying alternate site...' });
      await chrome.tabs.update(tab.id, { url: task.altUrl });
      await sleep(2000);
      result = await waitAndExtractTargetUrl(tab.id, task.taskId, task.altPlatform, task.raw_name);
      if (result.url) {
        targetUrl = result.url;
        confidence = result.confidence;
        currentPlatform = task.altPlatform;
        currentPlatformId = currentPlatform === 'fps' ? 1 : 2;
      }
    }

    if (!targetUrl) throw new Error('No profile URL found');

    updateTaskState(task.taskId, { progress: 60, message: 'On profile → extracting data...' });
    await chrome.tabs.update(tab.id, { url: targetUrl });

    updateTaskState(task.taskId, { progress: 85, message: 'Extracting contacts...' });
    const finalData = await waitAndExtractFinalData(tab.id, task.taskId, currentPlatform, task.raw_name);

    const hasData = finalData.extractedData.phone_numbers.length > 0 ||
                    finalData.extractedData.emails.length > 0 ||
                    finalData.extractedData.best_phone_number ||
                    finalData.extractedData.best_email ||
                    finalData.extractedData.name;

    const status = hasData ? 'done' : 'error';

    await sendToApi(task.taskId, finalData.extractedData, targetUrl, workerId, currentPlatformId, status, confidence);

    updateTaskState(task.taskId, { progress: 100, status: 'complete', message: 'Success' });

    currentStatus.details.completed++;
    currentStatus.details.inProgress--;
    updateStatus(`Completed: ${currentStatus.details.completed}/${currentStatus.details.total}`, '', currentStatus.details);

  } catch (err) {
    console.error(`[TASK ${task.taskId}] Failed:`, err.message);
    const empty = { name: '', phone_numbers: [], emails: [], best_phone_number: '', best_email: '' };
    await sendToApi(task.taskId, empty, targetUrl || task.startUrl, workerId, currentPlatformId, 'error', confidence || 0);

    updateTaskState(task.taskId, { progress: 100, status: 'error', message: err.message.substring(0, 50) });

    currentStatus.details.failed++;
    currentStatus.details.inProgress--;
    updateStatus(`Failed: ${currentStatus.details.failed}/${currentStatus.details.total}`, '', currentStatus.details);
  } finally {
    if (tabId) {
      try {
        await chrome.tabs.remove(tabId);
      } catch (e) {
        console.log(`[TASK ${task.taskId}] Tab already closed`);
      }
    }
  }
}

// ===== WAIT AND EXTRACT TARGET URL (FIXED WITH TIMEOUT) =====
async function waitAndExtractTargetUrl(tabId, taskId, platform, raw_name) {
  const checkInterval = 1000;
  const maxWait = 60000;
  const startTime = Date.now();

  while (Date.now() - startTime < maxWait) {
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          const blocked = document.title.includes('Just a moment') ||
                          document.querySelector('iframe[src*="challenges.cloudflare"]') ||
                          document.body.innerText.includes('Checking your browser');
          if (blocked) return { blocked: true };
          return { html: document.documentElement.outerHTML };
        }
      });

      if (res?.result?.blocked) {
        // Cloudflare challenge - wait indefinitely but check periodically
        await sleep(checkInterval);
        continue;
      }

      if (!res?.result?.html) {
        await sleep(checkInterval);
        continue;
      }

      const html = res.result.html;

      // Try LD+JSON first
      const ld = extractLdJsonFromHtml(html);
      if (ld.length > 0) {
        let match = platform === 'fps' ? extractFpsPersonUrl(ld, raw_name) : extractSpfPersonUrl(ld, raw_name);
        if (match.url && match.confidence >= 30) {
          return match;
        }
      }

      // FPS address fallback
      if (platform === 'fps' && html.includes('class="people-list"')) {
        const match = findProfileUrlWithConfidence(html, raw_name);
        if (match.url && match.confidence >= 30) {
          return match;
        }
      }

      // If we've waited long enough and have some HTML but no match, give up
      if (Date.now() - startTime > maxWait) {
        console.log(`[TASK ${taskId}] Timeout waiting for profile URL`);
        return { url: null, confidence: 0 };
      }

    } catch (e) {
      // Tab might not be ready yet
      if (Date.now() - startTime > maxWait) {
        console.log(`[TASK ${taskId}] Timeout with errors`);
        return { url: null, confidence: 0 };
      }
    }
    await sleep(checkInterval);
  }

  return { url: null, confidence: 0 };
}

// ===== WAIT AND EXTRACT FINAL DATA (FIXED WITH GUARANTEED RETURN) =====
async function waitAndExtractFinalData(tabId, taskId, platform, raw_name) {
  const checkInterval = 2000;
  const minWait = 10000;
  const maxWait = 90000;
  const startTime = Date.now();
  
  await sleep(minWait);

  let best = { name: '', phone_numbers: [], emails: [], best_phone_number: '', best_email: '' };
  let consecutiveFailures = 0;
  const maxConsecutiveFailures = 5;

  while (Date.now() - startTime < maxWait) {
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        func: (plat) => {
          const blocked = document.title.includes('Just a moment') ||
                          document.querySelector('iframe[src*="challenges.cloudflare"]');
          if (blocked) return { blocked: true };

          const hasData = document.querySelectorAll('script[type="application/ld+json"]').length > 0 ||
                          (plat === 'fps' && document.documentElement.outerHTML.includes('wam.init'));
          if (hasData || document.body.innerHTML.length > 1000) {
            return { html: document.documentElement.outerHTML };
          }
          return { empty: true };
        },
        args: [platform]
      });

      if (res?.result?.blocked) {
        // Reset timer during Cloudflare challenges
        consecutiveFailures = 0;
        await sleep(checkInterval);
        continue;
      }

      if (res?.result?.empty) {
        consecutiveFailures++;
        if (consecutiveFailures >= maxConsecutiveFailures) {
          console.log(`[TASK ${taskId}] Too many empty responses, returning best data`);
          return { extractedData: best };
        }
        await sleep(checkInterval);
        continue;
      }

      if (!res?.result?.html) {
        consecutiveFailures++;
        if (consecutiveFailures >= maxConsecutiveFailures) {
          console.log(`[TASK ${taskId}] Too many failures, returning best data`);
          return { extractedData: best };
        }
        await sleep(checkInterval);
        continue;
      }

      // Reset failure counter on successful HTML fetch
      consecutiveFailures = 0;

      const html = res.result.html;
      const ld = extractLdJsonFromHtml(html);

      let data = { name: '', phone_numbers: [], emails: [], best_phone_number: '', best_email: '' };

      if (platform === 'fps') {
        const wam = extractWamInitObject(html, true);
        data.name = wam ? `${wam.fn||''} ${wam.mn||''} ${wam.ln||''}`.trim() : '';
        data.best_phone_number = wam?.phone || '';
        data.best_email = wam?.email || '';
        data.phone_numbers = extractPhoneNumbers(ld);
        const faq = extractFAQPage(ld);
        const emails = emailExtractorRegx(faq);
        if (emails) data.emails = emails.split(',').filter(e => e);
      } else {
        const faq = extractFAQPage(ld);
        const emails = emailExtractorRegx(faq);
        data.best_email = emails;
        data.name = spfExtractName(ld);
        data.phone_numbers = spfExtractPhoneNumbers(ld);
        data.emails = spfExtractEmails(ld);
      }

      // Update best if this is better
      if (data.phone_numbers.length > (best?.phone_numbers?.length || 0) ||
          data.emails.length > (best?.emails?.length || 0) ||
          data.best_phone_number || data.best_email) {
        best = data;
      }

      // If we have good data, return immediately
      if (data.phone_numbers.length > 0 || data.emails.length > 0 || 
          data.best_phone_number || data.best_email) {
        console.log(`[TASK ${taskId}] Found data, returning`);
        return { extractedData: data };
      }

    } catch (e) {
      console.log(`[TASK ${taskId}] Extract error:`, e.message);
      consecutiveFailures++;
      if (consecutiveFailures >= maxConsecutiveFailures) {
        console.log(`[TASK ${taskId}] Too many errors, returning best data`);
        return { extractedData: best };
      }
    }
    await sleep(checkInterval);
  }

  // Timeout reached, return best data we found
  console.log(`[TASK ${taskId}] Timeout reached, returning best data`);
  return { extractedData: best };
}

// ===== AUTOPILOT (FIXED) =====
async function checkForNextBatch(workerId) {
  if (!autopilotEnabled || isFetchingNextBatch || isProcessingBatch || !currentBatchCode) {
    return;
  }

  const finished = currentStatus.details.completed + currentStatus.details.failed;
  const total = currentStatus.details.total;
  
  // Only start next batch when current batch is completely done
  if (finished >= total && currentStatus.details.inProgress === 0) {
    console.log('[AUTOPILOT] Starting next batch...');
    isFetchingNextBatch = true;
    
    // Small delay to ensure UI updates
    await sleep(1000);
    
    try {
      await startScrapingProcess(workerId, currentBatchCode);
    } catch (error) {
      console.error('[AUTOPILOT] Error starting next batch:', error);
      finishStatus('Autopilot error', 'error');
    } finally {
      isFetchingNextBatch = false;
    }
  }
}

// ===== SEND TO API (FIXED) =====
async function sendToApi(taskId, extractedData, targetUrl, workerId, platformId, status, confidence) {
  try {
    console.log(`[TASK ${taskId}] Sending API request...`);

    const apiPayload = {
      scraped_name: extractedData.name || '',
      scraped_emails: Array.isArray(extractedData.emails)
        ? extractedData.emails.join(',')
        : (extractedData.emails || ""),
      scraped_numbers: Array.isArray(extractedData.phone_numbers)
        ? extractedData.phone_numbers.join(',')
        : (extractedData.phone_numbers || ""),
      best_email: extractedData.best_email || '',
      best_number: extractedData.best_phone_number || '',
      status: status,
      scrapped_from: platformId,
      scraped_by: workerId,
      profile_url: targetUrl || '',
      confidence: confidence || 0
    };

    console.log(`[TASK ${taskId}] API Payload:`, apiPayload);

    const response = await fetch(`https://backendproperty.bulkscraper.cloud/api/data/${taskId}/update`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(apiPayload)
    });

    console.log(`[TASK ${taskId}] API Response status: ${response.status} ${response.statusText}`);

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[TASK ${taskId}] API Error body:`, errorText);
      // Don't throw - we still want to mark task as complete
    } else {
      console.log(`[TASK ${taskId}] API update successful`);
    }
  } catch (error) {
    console.error(`[TASK ${taskId}] API request failed:`, error.message);
    // Don't throw - task should still complete
  }
}

// ===== HELPER FUNCTIONS =====
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchTasksFromApi(limit = 10, batchCode = null, lowConf = false) {
  let response;
  if (!lowConf) {
    response = await fetch(
      `https://backendproperty.bulkscraper.cloud/api/data/top/${limit}?batch=${batchCode}`,
      { method: "GET", redirect: "follow" }
    );
  } else {
    response = await fetch(
      `https://backendproperty.bulkscraper.cloud/api/data-lowconf/top/${limit}?batch=${batchCode}`,
      { method: "GET", redirect: "follow" }
    );
  }

  if (!response.ok) throw new Error("Failed to fetch tasks from API");

  const data = await response.json();

  return data.map((item, index) => ({
    taskId: item.id ?? `task_${index}`,
    fastpeoplesearch_url: item.fastpeoplesearch_url,
    searchpeoplefree_url: item.searchpeoplefree_url,
    raw_name: item.raw_name,
  }));
}

function extractLdJsonFromHtml(htmlInput) {
  const regex = /<script\s+type=["']application\/ld\+json["']>(.*?)<\/script>/gis;
  const results = [];
  let match;

  while ((match = regex.exec(htmlInput)) !== null) {
    let rawContent = match[1].trim();

    if (rawContent) {
      try {
        rawContent = rawContent.replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "");
        rawContent = rawContent.replace(/;\s*$/, "");
        rawContent = rawContent.replace(/,(\s*[}\]])/g, "$1");

        const jsonObject = JSON.parse(rawContent);

        if (Array.isArray(jsonObject)) {
          results.push(...jsonObject);
        } else {
          results.push(jsonObject);
        }

      } catch (e) {
        console.error("Failed to parse JSON:", e.message);
      }
    }
  }
  return results;
}

function extractPhoneNumbers(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  for (const item of ldJson) {
    if (item['@type'] === 'Person' && item.telephone) {
      return Array.isArray(item.telephone) ? item.telephone : [item.telephone];
    }

    if (item['@graph'] && Array.isArray(item['@graph'])) {
      for (const graphItem of item['@graph']) {
        if (graphItem['@type'] === 'Person' && graphItem.telephone) {
          return Array.isArray(graphItem.telephone) ? graphItem.telephone : [graphItem.telephone];
        }
      }
    }
  }

  return [];
}

function extractWamInitObject(htmlContent, decodeEntities = false) {
  const match = htmlContent.match(/wam\.init\({([^}]+(?:}[^}]*)*)\}\);/s);
  if (!match) return null;

  const content = match[1];
  const result = {};

  const regex = /(\w+)\s*:\s*'([^']*)'|(\w+)\s*:\s*"([^"]*)"|(\w+)\s*:\s*(\w+(?:\s*==\s*'[^']*'\s*\?\s*\w+\s*:\s*\w+)?)/g;

  let m;
  while ((m = regex.exec(content)) !== null) {
    if (m[1]) {
      result[m[1]] = m[2];
    } else if (m[3]) {
      result[m[3]] = m[4];
    } else if (m[5]) {
      const value = m[6];
      if (value === 'true') result[m[5]] = true;
      else if (value === 'false') result[m[5]] = false;
      else if (value.includes('?')) result[m[5]] = false;
      else result[m[5]] = value;
    }
  }

  return standardizeData(result, decodeEntities);
}

function standardizeData(obj, decodeEntities) {
  if (!obj || typeof obj !== 'object') return obj;

  if (Array.isArray(obj)) {
    return obj.map(item => standardizeData(item, decodeEntities));
  }

  const result = {};

  for (const key in obj) {
    let value = obj[key];

    if (typeof value === 'string') {
      value = decodeURIComponent(value.replace(/\+/g, ' '));

      if (decodeEntities) {
        value = decodeHTMLEntities(value);
      }

      if (isEmail(value)) {
        value = value.toLowerCase().trim();
      }

      if (isPhone(value)) {
        value = standardizePhone(value);
      }
    } else if (typeof value === 'object' && value !== null) {
      value = standardizeData(value, decodeEntities);
    }

    result[key] = value;
  }

  return result;
}

function isEmail(str) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str);
}

function isPhone(str) {
  const cleaned = str.replace(/[\s\-\(\)\+\.]/g, '');
  return /^\d{7,15}$/.test(cleaned);
}

function standardizePhone(phone) {
  let cleaned = phone.trim();
  const hasPlus = cleaned.startsWith('+');
  cleaned = cleaned.replace(/\D/g, '');

  return hasPlus ? '+' + cleaned : cleaned;
}

function decodeHTMLEntities(str) {
  const entities = {
    '&amp;': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&#39;': "'",
    '&apos;': "'",
    '&#x27;': "'",
    '&#x2F;': '/',
    '&nbsp;': ' '
  };

  return str.replace(/&[^;]+;/g, match => entities[match] || match);
}

function extractFAQPage(ldJsonArray) {
  console.log("Extracting FAQPage from LD+JSON:", ldJsonArray);
  
  if (!Array.isArray(ldJsonArray)) return null;
  
  for (const item of ldJsonArray) {
    if (item['@type'] === 'FAQPage' && item.mainEntity) {
      return item.mainEntity;
    }
  }
  
  return null;
}

function emailExtractorRegx(mainEntity) {
  if (!mainEntity || !Array.isArray(mainEntity)) return "";

  const emailRegex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g;
  const emailSet = new Set();

  for (const item of mainEntity) {
    const textContent = item?.acceptedAnswer?.text;
    
    if (textContent && typeof textContent === "string") {
      const matches = textContent.match(emailRegex);
      if (matches) {
        matches.forEach(email => {
          emailSet.add(email.toLowerCase().trim());
        });
      }
    }
  }

  return Array.from(emailSet).join(",");
}

// ===== SPF-SPECIFIC EXTRACTORS =====
function spfExtractName(ldJson) {
  if (!Array.isArray(ldJson)) return '';

  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (personBlock && personBlock.name) {
    return personBlock.name.trim();
  }

  return '';
}

function spfExtractPhoneNumbers(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (!personBlock || !personBlock.telephone) return [];

  if (typeof personBlock.telephone === 'string') {
    return [personBlock.telephone.trim()];
  }

  if (Array.isArray(personBlock.telephone)) {
    return personBlock.telephone.map(num => num.trim()).filter(num => num);
  }

  return [];
}

function spfExtractEmails(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  const personBlock = ldJson.find(block => block['@type'] === 'Person');
  if (!personBlock || !personBlock.email) return [];

  if (typeof personBlock.email === 'string') {
    return [personBlock.email.trim().toLowerCase()];
  }

  if (Array.isArray(personBlock.email)) {
    return personBlock.email.map(email => email.trim().toLowerCase()).filter(email => email);
  }

  return [];
}

function spfExtractFAQ(ldJson) {
  if (!Array.isArray(ldJson)) return [];

  const faqBlock = ldJson.find(block => block['@type'] === 'FAQPage');

  if (faqBlock && Array.isArray(faqBlock.mainEntity)) {
    return faqBlock.mainEntity;
  }

  return [];
}

function updateTaskState(taskId, updates) {
  const taskIndex = currentStatus.tasks.findIndex(t => t.taskId === taskId);
  if (taskIndex > -1) {
    currentStatus.tasks[taskIndex] = { ...currentStatus.tasks[taskIndex], ...updates };
  }
  
  chrome.runtime.sendMessage({ 
    type: 'STATUS_UPDATE', 
    status: currentStatus 
  }).catch(() => {});
}

function findProfileUrlWithConfidence(htmlSource, targetName) {
  if (!htmlSource || typeof htmlSource !== 'string') {
    return { url: null, confidence: 0, displayedName: '' };
  }
  if (!targetName || typeof targetName !== 'string') {
    return { url: null, confidence: 0, displayedName: '' };
  }

  const normalizedTarget = targetName
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase();

  const targetTokens = normalizedTarget
    .replace(/,/g, ' ')
    .split(' ')
    .filter(t => t.length > 0);

  const cleanTokens = targetTokens.filter(t => !['jr', 'sr', 'ii', 'iii', 'iv'].includes(t));

  let bestMatch = {
    url: null,
    confidence: 0,
    displayedName: ''
  };

  const linkRegex = /<a[^>]+href=["']\/([^"']*?_id_[A-Z0-9\-]+)["'][^>]*>(.+?)<\/a>/gi;

  let match;
  while ((match = linkRegex.exec(htmlSource)) !== null) {
    const relativeHref = '/' + match[1];
    const rawText = match[2];

    const displayedText = rawText
      .replace(/<[^>]*>/g, '')
      .trim();

    if (!displayedText) continue;

    const normalizedDisplayed = displayedText
      .toLowerCase()
      .replace(/\s+/g, ' ');

    const displayedTokens = normalizedDisplayed.split(' ');

    let matchedTokens = 0;

    for (const token of cleanTokens) {
      if (displayedTokens.some(dt => dt === token || dt.startsWith(token) || token.startsWith(dt))) {
        matchedTokens++;
      }
    }

    let confidence = 0;

    if (matchedTokens === cleanTokens.length && cleanTokens.length >= 2) {
      confidence = 100;
    } else if (matchedTokens >= 2) {
      confidence = 80 + (matchedTokens / cleanTokens.length) * 20;
    } else if (matchedTokens >= 1 && cleanTokens.some(t => displayedTokens.includes(t))) {
      confidence = 40 + matchedTokens * 20;
    }

    if (normalizedDisplayed === normalizedTarget) {
      confidence = 100;
    }

    if (targetName.match(/,\s*[A-Z]\s*$/) && displayedText.match(/\s[A-Z]\s/)) {
      confidence = Math.min(100, confidence + 10);
    }

    confidence = Math.round(confidence);

    if (confidence > bestMatch.confidence) {
      bestMatch = {
        url: 'https://www.fastpeoplesearch.com' + relativeHref,
        confidence: confidence,
        displayedName: displayedText
      };
    }
  }

  return bestMatch;
}

console.log('Background service worker initialized - FIXED VERSION');